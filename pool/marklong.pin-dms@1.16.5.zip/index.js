(function (exports) {
	/*
	 * Pin DMs for Valenced.
	 * The idea comes from PinDMs for Vencord and BetterDiscord. The code is written from scratch for Valenced.
	 * Pinned chats go to the top of the DM list. They can be put in coloured sections that can be folded away.
	 * Keep `(function` as the first thing in this file: Valenced loads it as `return <file>`.
	 */
	var VERSION = '1.16.4'
	var INSTANCE = {}
	var defaults = { pinsJson: '[]', sectionsJson: '[]', assignJson: '{}', pins: [], stripOn3: false, stripBelow2: false, hidePinned2: false }
	var DM = 1
	var GROUP_DM = 3
	var METHODS = ['getPrivateChannelIds', 'getSortedChannels']
	var EDIT_KEY = 'marklong.pin-dms.edit'
	var MENU_KEY = 'marklong.pin-dms.menu'
	var PRESETS = [
		'#1abc9c', '#2ecc71', '#3498db', '#9b59b6', '#e91e63', '#f1c40f', '#e67e22', '#e74c3c', '#95a5a6', '#607d8b',
		'#11806a', '#1f8b4c', '#206694', '#71368a', '#ad1457', '#c27c0e', '#a84300', '#992d22', '#979c9f', '#546e7a',
	]

	var storage
	var listeners = []
	var status = { store: 'not found', hooks: [], menus: 0, list: 'not seen yet', headers: false, error: '', reordered: 0, lists: 0, headerLists: 0, unmatched: [], shapes: [], listKey: [], rowLists: [], activity: {}, rowHeaders: 0, pinMethods: [], sortShapes: [], screens: [], voiceAnchor: false, voiceCards: [], cards: [], detail: {}, order: [], fastList: '', hdRows: 0, labelRows: 0, sheetKeys: [], pinRow: '', pinSheets: 0, strip: 0, lastOpen: '' }
	var memo = {}

	function finders() { return valenced.modules.finders }
	function stores() { return valenced.discord.flux.Stores }
	function sheets() { return valenced.discord.actions.ActionSheetActionCreators }
	function changed() { listeners.slice().forEach(function (l) { try { l() } catch (e) {} }) }
	function toast(text) {
		try { valenced.discord.actions.ToastActionCreators.open('MARKLONG_PIN_DMS', { text: String(text) }) } catch (e) {}
	}
	function h(type, props) {
		var children = Array.prototype.slice.call(arguments, 2)
		var rt = valenced.react.ReactJSXRuntime
		var p = Object.assign({}, props)
		var key = p.key
		delete p.key
		if (children.length === 1) p.children = children[0]
		else if (children.length > 1) p.children = children
		return (children.length > 1 ? rt.jsxs : rt.jsx)(type, p, key)
	}
	function parse(text, fallback) {
		try { var v = JSON.parse(text); return v === null || v === undefined ? fallback : v } catch (e) { return fallback }
	}

	// ---- What is saved -----------------------------------------------------------------------------
	// Everything is saved as text, so saving always replaces the old value and nothing is merged by accident.
	function read() {
		var s = (storage && storage.cache) || {}
		var pinsText = s.pinsJson !== undefined ? s.pinsJson : s.pins ? JSON.stringify(s.pins) : '[]' // version 1.0 saved a plain list
		var pins = parse(pinsText, [])
		var sections = parse(s.sectionsJson !== undefined ? s.sectionsJson : '[]', [])
		var assign = parse(s.assignJson !== undefined ? s.assignJson : '{}', {})
		return {
			pins: Array.isArray(pins) ? pins.filter(function (x) { return typeof x === 'string' }) : [],
			sections: Array.isArray(sections) ? sections.filter(function (x) { return x && typeof x.id === 'string' }) : [],
			assign: assign && typeof assign === 'object' && !Array.isArray(assign) ? assign : {},
		}
	}
	var rowVersion = 0
	function commit(state) {
		memo = {}
		rowVersion++
		var patch = { pinsJson: JSON.stringify(state.pins), sectionsJson: JSON.stringify(state.sections), assignJson: JSON.stringify(state.assign) }
		try { if (storage && typeof storage.set === 'function') storage.set(patch) } catch (e) {}
		try { if (storage && storage.cache) Object.assign(storage.cache, patch) } catch (e) {}
		refreshList()
		// The rows draw before the list has worked out the new labels; a second pass draws them.
		setTimeout(function () { refreshList() }, 350)
	}
	function sectionOf(state, id) {
		var sid = state.assign[id]
		if (!sid) return undefined
		for (var i = 0; i < state.sections.length; i++) if (state.sections[i].id === sid) return state.sections[i]
	}
	function cleanColor(text) {
		var m = /^#?([0-9a-f]{6})$/i.exec(String(text || '').trim())
		return m ? '#' + m[1].toLowerCase() : null
	}
	function tint(hex, alpha) {
		var m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''))
		if (!m) return 'rgba(128,132,142,' + alpha + ')'
		var n = parseInt(m[1], 16)
		return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + alpha + ')'
	}
	/** A solid colour: the section colour mixed into a dark base, so a tag hides what is under it cleanly. */
	function solid(hex, alpha, base) {
		var m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''))
		var b = /^#?([0-9a-f]{6})$/i.exec(String(base || '#1a1b1e'))
		if (!m || !b) return '#26272b'
		var n = parseInt(m[1], 16)
		var k = parseInt(b[1], 16)
		function mix(shift) { return Math.round(((n >> shift) & 255) * alpha + ((k >> shift) & 255) * (1 - alpha)) }
		return 'rgb(' + mix(16) + ',' + mix(8) + ',' + mix(0) + ')'
	}
	function newId() { return 's' + Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36) }

	function sortStore() {
		var s = stores().PrivateChannelSortStore
		if (s) return s
		var f = finders()
		return f.lookupModule(f.filters.withProps('getPrivateChannelIds'))[0]
	}

	// ---- Putting pinned chats first, section by section ---------------------------------------------
	/** The chat an entry stands for. Rows of the DM list can carry the chat in a few places. */
	function idOf(entry, depth) {
		depth = depth || 0
		if (typeof entry === 'string') return looksLikeChat(entry) ? entry : undefined
		if (!entry || typeof entry !== 'object' || depth > 2) return undefined
		var keys = ['id', 'channel_id', 'channelId']
		for (var i = 0; i < keys.length; i++) {
			var v = entry[keys[i]]
			if (typeof v === 'string' && looksLikeChat(v)) return v
		}
		var inner = ['channel', 'item', 'data', 'row', 'dm', 'value']
		for (var j = 0; j < inner.length; j++) {
			if (entry[inner[j]] && typeof entry[inner[j]] === 'object') {
				var found = idOf(entry[inner[j]], depth + 1)
				if (found) return found
			}
		}
		return undefined
	}
	var deepCache = typeof WeakMap === 'function' ? new WeakMap() : null
	/** Last resort: a row that carries a chat id somewhere I do not look by name. */
	function deepId(entry) {
		if (!entry || typeof entry !== 'object' || !deepCache) return undefined
		if (deepCache.has(entry)) return deepCache.get(entry)
		var found
		try {
			var text = JSON.stringify(entry, skipMessages) || ''
			var all = text.slice(0, 3000).match(/\d{17,20}/g) || []
			for (var i = 0; i < all.length; i++) { if (isDm(all[i])) { found = all[i]; break } }
		} catch (e) {}
		deepCache.set(entry, found)
		return found
	}
	/**
	 * Leaves out functions, and messages with what hangs off them. A search result (Media, Pins, Links, Files of a chat) carries
	 * its message, and the message carries the chat's id; that does not make the result a row of the DM list.
	 */
	var MESSAGE_KEY = /^(message|messages|messageId|attachment|attachments|embed|embeds|referencedMessage|messageReference)$/
	function skipMessages(k, v) { return typeof v === 'function' || MESSAGE_KEY.test(k) ? undefined : v }
	function chatId(entry) { return idOf(entry, 0) || deepId(entry) }
	/** A list of DM rows holds each chat once. A list where a chat comes back more than once (search results of one chat) is not one. */
	function distinctIds(ids) {
		var seen = {}
		for (var i = 0; i < ids.length; i++) {
			if (!ids[i]) continue
			if (seen[ids[i]]) return false
			seen[ids[i]] = 1
		}
		return true
	}
	function looksLikeChat(id) {
		return /^\d{15,}$/.test(id) || isDm(id)
	}

	// ---- Discord's own pinned DMs ----------------------------------------------------------------------
	// Discord hands its pinned DMs to the list separately and draws them above everything. With this on (the default) they are
	// put in with the rest: a chat pinned both ways goes to the top of its section, any other at the top of Direct messages.
	var nativeFavs = []
	function nativeOn() {
		try { return !storage || !storage.cache || storage.cache.nativeInto !== false } catch (e) { return true }
	}
	var favCache = null
	function mergeFavorites(d) {
		try {
			var fav = d.channelFavorites
			if (!nativeOn() || !Array.isArray(fav) || !fav.length || !Array.isArray(d.channels) || !Array.isArray(d.sections)) { if (!nativeOn() || !Array.isArray(fav) || !fav.length) nativeFavs = []; return d }
			if (!read().pins.length) return d
			if (d.sections[0] !== fav.length || d.sections[1] !== d.channels.length) return d
			if (favCache && favCache.src === d) return favCache.out
			var ids = fav.map(chatId).filter(Boolean)
			var have = {}
			ids.forEach(function (id) { have[id] = 1 })
			var channels = fav.concat(d.channels.filter(function (e) { return !have[chatId(e)] }))
			var sections = d.sections.slice()
			sections[0] = 0
			sections[1] = channels.length
			var out = Object.assign({}, d, { channels: channels, channelFavorites: [], sections: sections })
			nativeFavs = ids
			favCache = { src: d, out: out }
			if (status.listKey.indexOf('native pins merged') < 0) { status.listKey.push('native pins merged'); changed() }
			return out
		} catch (e) {
			return d
		}
	}
	/** Within one group, Discord's pinned DMs first (in Discord's order), then the rest in the plugin's order. */
	function favsFirst(group) {
		if (!nativeFavs.length || !nativeOn()) return group
		var natives = nativeFavs.filter(function (id) { return group.indexOf(id) >= 0 })
		return natives.length ? natives.concat(group.filter(function (id) { return natives.indexOf(id) < 0 })) : group
	}
	/** Pinned chats with no section first, then each section's chats in order, then everything else. */
	function pinnedOrder(ids) {
		var state = read()
		var out = []
		var seen = {}
		var loose = state.pins.filter(function (id) { return ids.indexOf(id) >= 0 && !sectionOf(state, id) })
		favsFirst(loose).forEach(function (id) { if (!seen[id]) { out.push(id); seen[id] = 1 } })
		state.sections.forEach(function (section) {
			var group = state.pins.filter(function (id) { return ids.indexOf(id) >= 0 && state.assign[id] === section.id })
			favsFirst(group).forEach(function (id) { if (!seen[id]) { out.push(id); seen[id] = 1 } })
		})
		return out
	}

	/** Some stores give the DMs out as an object (id -> chat). Its key order is the order the list is drawn in. */
	function pinnedObject(obj, method) {
		try {
			var state = read()
			if (!state.pins.length || obj instanceof Map || obj instanceof Set) return obj
			var keys = Object.keys(obj)
			if (keys.length < 2 || !keys.slice(0, 5).every(function (k) { return /^\d{15,}$/.test(k) })) return obj
			var a = status.activity[method] || (status.activity[method] = { calls: 0, moved: 0, len: 0, pins: 0 })
			a.calls++
			a.len = keys.length
			var first = pinnedOrder(keys)
			a.pins = first.length
			if (!first.length) return obj
			var key = method + '|' + JSON.stringify(state) + '|' + keys.join(',')
			if (memo[method] && memo[method].key === key) return memo[method].result
			var chosen = {}
			first.forEach(function (id) { chosen[id] = 1 })
			var ordered = first.concat(keys.filter(function (k) { return !chosen[k] }))
			var same = ordered.every(function (k, i) { return k === keys[i] })
			if (same) return obj
			var out = {}
			ordered.forEach(function (k) { out[k] = obj[k] })
			memo[method] = { key: key, result: out }
			a.moved++
			a.before = keys.slice(0, 3).map(function (k) { return 's' + k.slice(-4) }).join(',')
			a.after = ordered.slice(0, 3).map(function (k) { return 's' + k.slice(-4) }).join(',')
			status.reordered++
			changed()
			return out
		} catch (e) {
			return obj
		}
	}

	var lastIds = []
	function labelOf(entry) {
		try {
			if (typeof entry === 'string') return 's' + entry.slice(-4)
			if (entry && typeof entry === 'object') return 'o' + String(entry.name || entry.id || '?').slice(0, 6)
		} catch (e) {}
		return typeof entry
	}
	function hideOn() {
		try { return !storage || !storage.cache || storage.cache.hidePinned2 === true } catch (e) { return true }
	}
	/** The pinned chats live in the strip, so they are left out of the normal list. */
	function hidePinned(list, method) {
		try {
			var state = read()
			if (!state.pins.length) return list
			var isObj = list && typeof list === 'object' && !Array.isArray(list)
			var out = list
			if (isObj) {
				if (list instanceof Map || list instanceof Set) return list
				var keys = Object.keys(list)
				if (keys.length < 2 || !keys.slice(0, 5).every(function (k) { return /^\d{15,}$/.test(k) })) return list
				var rest = keys.filter(function (k) { return state.pins.indexOf(k) < 0 })
				if (rest.length === keys.length) return list
				var key = method + '|h|' + state.pins.join(',') + '|' + keys.join(',')
				if (memo[method] && memo[method].key === key) return memo[method].result
				out = {}
				rest.forEach(function (k) { out[k] = list[k] })
				memo[method] = { key: key, result: out }
			} else if (Array.isArray(list)) {
				var ids = list.map(function (e) { return idOf(e, 0) })
				if (!ids.some(function (id) { return id && state.pins.indexOf(id) >= 0 })) return list
				var key2 = method + '|h|' + state.pins.join(',') + '|' + ids.join(',')
				if (memo[method] && memo[method].key === key2) return memo[method].result
				out = list.filter(function (e, i) { return !(ids[i] && state.pins.indexOf(ids[i]) >= 0) })
				memo[method] = { key: key2, result: out }
			} else return list
			var a = status.activity[method] || (status.activity[method] = { calls: 0, moved: 0, len: 0, pins: 0 })
			a.calls++
			a.moved++
			a.len = isObj ? Object.keys(list).length : list.length
			a.after = 'hid ' + (a.len - (isObj ? Object.keys(out).length : out.length))
			status.reordered++
			changed()
			return out
		} catch (e) {
			return list
		}
	}
	function pinnedFirst(list, method) {
		if (hideOn() && list && typeof list === 'object') { var hidden = hidePinned(list, method); if (hidden !== list) { try { if (/getPrivateChannelIds/.test(method) && Array.isArray(hidden) && typeof hidden[0] === 'string') lastIds = hidden } catch (e) {} return hidden } }
		if (list && typeof list === 'object' && !Array.isArray(list)) return pinnedObject(list, method)
		var out = pinnedFirstInner(list, method)
		try { if (/getPrivateChannelIds/.test(method) && Array.isArray(out) && typeof out[0] === 'string') lastIds = out } catch (e) {}
		try {
			var a = status.activity[method] || (status.activity[method] = { calls: 0, moved: 0, len: 0, pins: 0 })
			a.calls++
			if (Array.isArray(list)) {
				a.len = list.length
				a.pins = list.filter(function (e) { var id = idOf(e, 0); return id && read().pins.indexOf(id) >= 0 }).length
				if (out !== list) { a.moved++; a.after = out.slice(0, 3).map(labelOf).join(',') }
				a.before = list.slice(0, 3).map(labelOf).join(',')
			}
			if (a.calls <= 3 || a.calls % 20 === 0) changed()
		} catch (e) {}
		return out
	}
	function pinnedFirstInner(list, method) {
		var state = read()
		if (!Array.isArray(list) || !state.pins.length) return list
		var ids = list.map(function (entry) { return idOf(entry, 0) })
		var key = method + '|' + JSON.stringify(state) + '|' + ids.join(',')
		if (memo[method] && memo[method].key === key) return memo[method].result
		var byId = {}
		list.forEach(function (entry) { var id = idOf(entry); if (id) byId[id] = entry })
		var top = pinnedOrder(ids).map(function (id) { return byId[id] }).filter(function (entry) { return entry !== undefined })
		if (!top.length || top.length + list.filter(function (entry) { return top.indexOf(entry) < 0 }).length !== list.length) return list
		var chosen = {}
		pinnedOrder(ids).forEach(function (id) { chosen[id] = 1 })
		var result = top.concat(list.filter(function (entry) { return !chosen[idOf(entry)] }))
		memo[method] = { key: key, result: result }
		status.reordered++
		return result
	}

	function methodNames(obj) {
		var names = {}
		var o = obj
		var guard = 0
		while (o && o !== Object.prototype && guard++ < 6) {
			Object.getOwnPropertyNames(o).forEach(function (n) { names[n] = true })
			o = Object.getPrototypeOf(o)
		}
		return Object.keys(names)
	}

	/** Methods of the stores that give out the list of DMs, in whatever form. */
	var LIST_METHOD = /^(get)?(Mutable)?(Sorted)?(Private)?(DM)?Channels?(Ids)?$|^getSortedPrivateChannels$|^getPrivateChannelIds$|^getDMs?$/i

	/** Discord keeps its own pinned DMs. Our pins go into that group, first, and out of the plain one. */
	function pinAware(result, method) {
		var state = read()
		if (!Array.isArray(result) || !state.pins.length) return result
		var mine = pinnedOrder(state.pins.slice())
		if (!mine.length) return result
		var a = status.activity[method] || (status.activity[method] = { calls: 0, moved: 0, len: 0, pins: 0 })
		a.calls++
		a.len = result.length
		var out = result
		var plainStrings = result.every(function (e) { return typeof e === 'string' })
		var unpinned = /unpin/i.test(method)
		if (unpinned) {
			out = result.filter(function (e) { var id = idOf(e, 0); return !(id && state.pins.indexOf(id) >= 0) })
		} else if (plainStrings) {
			out = mine.concat(result.filter(function (e) { return mine.indexOf(e) < 0 }))
		} else {
			var cs = stores().ChannelStore
			var objs = []
			for (var i = 0; i < mine.length; i++) {
				var present = result.filter(function (e) { return idOf(e, 0) === mine[i] })[0]
				var obj = present || (cs && typeof cs.getChannel === 'function' ? cs.getChannel(mine[i]) : undefined)
				if (!obj) return result
				objs.push(obj)
			}
			out = objs.concat(result.filter(function (e) { var id = idOf(e, 0); return !(id && mine.indexOf(id) >= 0) }))
		}
		if (out !== result && out.length !== result.length && !unpinned && out.length !== result.length + mine.filter(function (id) { return !result.some(function (e) { return idOf(e, 0) === id }) }).length) return result
		a.moved++
		a.before = result.slice(0, 3).map(labelOf).join(',')
		a.after = out.slice(0, 3).map(labelOf).join(',')
		changed()
		return out
	}

	function hookStore(store, label, cleanup) {
		if (!store) return
		methodNames(store).forEach(function (method) {
			if (typeof store[method] !== 'function') return
			if (/pin/i.test(method) && !/^(_|constructor)/.test(method)) {
				if (status.pinMethods.indexOf(label + '.' + method) < 0) status.pinMethods.push(label + '.' + method)
				if (/^get/i.test(method) && !/^getPinn?ed?Channel$/i.test(method)) {
					try {
						cleanup(valenced.patcher.after(store, method, function (result) { try { return pinAware(result, label + '.' + method) } catch (e) { return result } }))
						status.hooks.push(label + '.' + method)
					} catch (e) {}
				}
				return
			}
			if (!LIST_METHOD.test(method.replace(/^get/, 'get'))) return
			if (!/private|sorted|dm/i.test(method)) return
			try {
				cleanup(valenced.patcher.after(store, method, function (result) { try { return pinnedFirst(result, label + '.' + method) } catch (e) { return result } }))
				status.hooks.push(label + '.' + method)
			} catch (e) {
				status.error = String((e && e.message) || e).slice(0, 80)
			}
		})
	}

	/** The DM tab sorts the chats by time after the stores hand them over. Put the pinned ones back first. */
	function sortFixEnabled() {
		try { return !storage || !storage.cache || storage.cache.sortFix !== false } catch (e) { return true }
	}
	/** Diagnostics: long arrays being sorted that hold a chat somewhere I do not look. */
	function noteSort(arr) {
		try {
			if (status.sortShapes.length >= 3 || arr.length > 400) return
			var first = arr[0]
			if (!first || typeof first !== 'object') return
			var text = JSON.stringify(first, function (k, v) { return typeof v === 'function' ? undefined : v }) || ''
			var m = text.slice(0, 2500).match(/\d{17,20}/g) || []
			var hit = m.filter(function (id) { return isDm(id) })[0]
			if (!hit) return
			var line = 'x' + arr.length + ' {' + Object.keys(first).slice(0, 6).join('/') + '}'
			if (status.sortShapes.indexOf(line) < 0) { status.sortShapes.push(line); changed() }
		} catch (e) {}
	}

	function fixSorted(arr) {
		try {
			if (!Array.isArray(arr) || arr.length < 8 || !sortFixEnabled()) return arr
			var state = read()
			if (!state.pins.length) return arr
			var probe = 0
			for (var i = 0; i < 3; i++) { if (idOf(arr[i], 0)) probe++ }
			if (probe < 3) { noteSort(arr); return arr }
			var ids = arr.map(function (e) { return idOf(e, 0) })
			var known = ids.filter(Boolean)
			if (known.length < arr.length * 0.8) return arr
			var first = pinnedOrder(known)
			if (!first.length) return arr
			var byId = {}
			arr.forEach(function (e, i) { if (ids[i]) byId[ids[i]] = e })
			var chosen = {}
			first.forEach(function (id) { chosen[id] = 1 })
			var slots = []
			arr.forEach(function (e, i) { if (ids[i]) slots.push(i) })
			var entries = first.map(function (id) { return byId[id] }).concat(arr.filter(function (e, i) { return ids[i] && !chosen[ids[i]] }))
			if (entries.length !== slots.length) return arr
			var changedAny = false
			slots.forEach(function (slot, n) { if (arr[slot] !== entries[n]) { arr[slot] = entries[n]; changedAny = true } })
			if (changedAny) {
				var a = status.activity['Array.sort'] || (status.activity['Array.sort'] = { calls: 0, moved: 0, len: 0, pins: 0 })
				a.calls++; a.moved++; a.len = arr.length; a.pins = first.length
				a.after = arr.slice(0, 3).map(labelOf).join(',')
				if (a.moved <= 3 || a.moved % 25 === 0) changed()
			}
			return arr
		} catch (e) {
			return arr
		}
	}

	function installStoreHooks(cleanup) {
		var store = sortStore()
		if (store) status.store = 'found'
		hookStore(store, 'SortStore', cleanup)
		try { hookStore(stores().ChannelStore, 'ChannelStore', cleanup) } catch (e) {}
	}

	function refreshList() {
		memo = {}
		var store = sortStore()
		try { if (store && typeof store.emitChange === 'function') store.emitChange() } catch (e) {}
		changed()
	}

	// ---- Changing things -------------------------------------------------------------------------------
	function isPinned(id) { return read().pins.indexOf(id) >= 0 }
	function pin(id, sectionId) {
		var state = read()
		if (state.pins.indexOf(id) < 0) state.pins.push(id)
		state.assign[id] = sectionId || ''
		commit(state)
	}
	function unpin(id) {
		var state = read()
		state.pins = state.pins.filter(function (x) { return x !== id })
		state.assign[id] = ''
		commit(state)
	}
	function moveIn(id, by) {
		var state = read()
		var groupOf = function (x) { var sec = sectionOf(state, x); return sec ? sec.id : '' }
		var group = state.pins.filter(function (x) { return groupOf(x) === groupOf(id) })
		var at = group.indexOf(id)
		var to = at + by
		if (at < 0 || to < 0 || to >= group.length) return
		var other = group[to]
		var a = state.pins.indexOf(id)
		var b = state.pins.indexOf(other)
		state.pins[a] = other
		state.pins[b] = id
		commit(state)
	}
	function saveSection(id, name, color) {
		var state = read()
		var cleaned = String(name || '').trim().slice(0, 30)
		if (!cleaned) return toast('Give the section a name')
		var hex = cleanColor(color)
		if (!hex) return toast('That colour is not valid. Use something like #00d4ff')
		var existing = state.sections.filter(function (s) { return s.id === id })[0]
		if (existing) { existing.name = cleaned; existing.color = hex } else state.sections.push({ id: newId(), name: cleaned, color: hex, collapsed: false })
		commit(state)
		return true
	}
	function deleteSection(id) {
		var state = read()
		state.sections = state.sections.filter(function (s) { return s.id !== id })
		Object.keys(state.assign).forEach(function (k) { if (state.assign[k] === id) state.assign[k] = '' })
		commit(state)
	}
	function moveSection(id, by) {
		var state = read()
		var at = state.sections.findIndex(function (s) { return s.id === id })
		var to = at + by
		if (at < 0 || to < 0 || to >= state.sections.length) return
		state.sections.splice(to, 0, state.sections.splice(at, 1)[0])
		commit(state)
	}
	function toggleCollapsed(id) {
		var state = read()
		var section = state.sections.filter(function (s) { return s.id === id })[0]
		if (!section) return
		section.collapsed = !section.collapsed
		commit(state)
		try { refreshList() } catch (e) {}
	}

	// ---- Names -----------------------------------------------------------------------------------
	function channelLabel(id) {
		try {
			var ch = stores().ChannelStore.getChannel(id)
			if (!ch) return 'Unknown chat (' + id.slice(-4) + ')'
			if (ch.name) return ch.name
			var ids = ch.recipients || (ch.rawRecipients || []).map(function (u) { return u && u.id })
			var names = (ids || []).map(function (uid) {
				var user = stores().UserStore.getUser(uid)
				return user ? user.globalName || user.username : null
			}).filter(Boolean)
			return names.join(', ') || 'Direct message'
		} catch (e) {
			return 'Direct message'
		}
	}
	function allDmIds() {
		var store = sortStore()
		try {
			var ids = store && typeof store.getPrivateChannelIds === 'function' ? store.getPrivateChannelIds() : []
			return (ids || []).map(chatId).filter(Boolean)
		} catch (e) { return [] }
	}
	function isDm(id) {
		try {
			var ch = stores().ChannelStore.getChannel(id)
			return !!ch && (ch.type === DM || ch.type === GROUP_DM)
		} catch (e) { return false }
	}

	// ---- Colours ----------------------------------------------------------------------------------------
	function hslToHex(hue, sat, light) {
		var s = sat / 100
		var l = light / 100
		var a = s * Math.min(l, 1 - l)
		function f(n) {
			var k = (n + hue / 30) % 12
			var c = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1)
			var hex = Math.round(255 * c).toString(16)
			return hex.length < 2 ? '0' + hex : hex
		}
		return '#' + f(0) + f(8) + f(4)
	}
	function hexToHue(hex) {
		var n = parseInt(String(hex).replace('#', ''), 16)
		var r = ((n >> 16) & 255) / 255
		var g = ((n >> 8) & 255) / 255
		var b = (n & 255) / 255
		var max = Math.max(r, g, b)
		var min = Math.min(r, g, b)
		if (max === min) return 0
		var d = max - min
		var hue = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4
		return Math.round(hue * 60) % 360
	}
	var HUES = []
	for (var hh = 0; hh < 360; hh += 15) HUES.push(hh)
	var SHADES = [[85, 100], [72, 100], [60, 90], [50, 100], [42, 85], [34, 70], [26, 60], [18, 50]] // [lightness, saturation]

	// ---- Sheets ------------------------------------------------------------------------------------------
	/** A sheet whose buttons stay at the bottom: `footer` is not part of the scrolling part. */
	// ---- The scrolling part of a sheet ---------------------------------------------------------------
	// Inside a bottom sheet a plain scroll view can lose its touches to the sheet. The sheet library has its own scroll view for that;
	// use it when it can be found, and fall back to the plain one if it cannot be drawn.
	var scrollPick = null
	var boundaryClass = null
	function sheetScrollComponent() {
		var RN = valenced.react.ReactNative
		if (scrollPick) return scrollPick
		var pick = RN.ScrollView
		try {
			if (!(storage && storage.cache && storage.cache.plainScroll === true)) {
				var D = valenced.discord.design.Design
				var c = D && (D.BottomSheetScrollView || D.ActionSheetScrollView)
				if (!c) { var f = finders(); var m = f.lookupModule(f.filters.withProps('BottomSheetScrollView'))[0]; c = m && m.BottomSheetScrollView }
				if (c) pick = c
			}
		} catch (e) {}
		scrollPick = pick
		return pick
	}
	function scrollBoundary() {
		if (boundaryClass) return boundaryClass
		var React = valenced.react.React
		if (typeof React.Component !== 'function') return null
		boundaryClass = class extends React.Component {
			constructor(p) { super(p); this.state = { bad: false } }
			static getDerivedStateFromError() { return { bad: true } }
			componentDidCatch() {}
			render() { return this.state.bad ? this.props.fallback : this.props.children }
		}
		return boundaryClass
	}
	function scrollView(RN, scrollProps, children) {
		var Scroll = sheetScrollComponent()
		var plain = h(RN.ScrollView, scrollProps, children)
		var Boundary = Scroll === RN.ScrollView ? null : scrollBoundary()
		if (!Boundary) return plain
		return h(Boundary, { fallback: plain }, h(Scroll, scrollProps, children))
	}

	/** The scrolling part of a sheet may be as tall as the window minus the fixed buttons and the room the sheet itself needs. */
	function sheetScrollMax(windowHeight, footer) {
		var rows = footer ? (Array.isArray(footer) ? footer.filter(Boolean).length : 1) : 0
		var footerH = rows ? rows * 52 + (rows - 1) * 8 + 28 : 0
		return Math.max(200, Math.round(windowHeight - footerH - (rows ? 200 : 150)))
	}
	function SheetBody(props) {
		var Design = valenced.discord.design.Design
		var RN = valenced.react.ReactNative
		var size = RN.useWindowDimensions ? RN.useWindowDimensions() : { height: 800 }
		return h(
			Design.ActionSheet,
			null,
			scrollView(RN, { style: { maxHeight: sheetScrollMax(size.height, props.footer) }, keyboardShouldPersistTaps: 'handled', nestedScrollEnabled: true, showsVerticalScrollIndicator: true }, h(Design.Stack, { spacing: 16, style: { padding: 16 } }, props.children)),
			props.footer ? h(RN.View, { style: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 18, gap: 8 } }, props.footer) : null,
		)
	}
	function openSheet(key, Component, props) {
		sheets().openLazy(Promise.resolve({ default: function () { return h(Component, props) } }), key, {})
	}

	/** Edit Category: a name and a colour, like the desktop plugin. */
	function EditSection(props) {
		var React = valenced.react.React
		var Design = valenced.discord.design.Design
		var RN = valenced.react.ReactNative
		var section = props.section
		var nameState = React.useState(section ? section.name : '')
		var colorState = React.useState(section ? section.color : PRESETS[2])
		var hexState = React.useState(section ? section.color : PRESETS[2])
		var hueState = React.useState(hexToHue(section ? section.color : PRESETS[2]))
		var color = colorState[0]
		function pick(hex) { colorState[1](hex); hexState[1](hex); hueState[1](hexToHue(hex)) }
		var hue = hueState[0]
		var footer = [
			h(
				RN.View,
				{ key: 'row', style: { flexDirection: 'row', gap: 10 } },
				h(RN.View, { style: { flex: 1 } }, h(Design.Button, { text: 'Cancel', variant: 'secondary', onPress: function () { sheets().hideActionSheet(EDIT_KEY) } })),
				h(RN.View, { style: { flex: 1 } }, h(Design.Button, {
					text: 'Save',
					variant: 'primary',
					onPress: function () {
						if (saveSection(section && section.id, nameState[0], cleanColor(hexState[0]) || color)) sheets().hideActionSheet(EDIT_KEY)
					},
				})),
			),
			section ? h(Design.Button, { key: 'del', text: 'Delete section', variant: 'destructive', onPress: function () { deleteSection(section.id); sheets().hideActionSheet(EDIT_KEY) } }) : null,
		]
		return h(
			SheetBody,
			{ footer: footer },
			h(Design.Text, { variant: 'heading-lg/bold' }, section ? 'Edit Category' : 'New Category'),
			h(Design.TextInput, { label: 'Name', placeholder: 'Boys', size: 'md', maxLength: 30, value: nameState[0], onChange: function (v) { nameState[1](v) } }),
			section && read().sections.length > 1
				? h(
						RN.View,
						{ style: { flexDirection: 'row', gap: 10 } },
						h(RN.View, { style: { flex: 1 } }, h(Design.Button, { text: '↑ Move up', size: 'sm', variant: 'secondary', onPress: function () { moveSection(section.id, -1) } })),
						h(RN.View, { style: { flex: 1 } }, h(Design.Button, { text: '↓ Move down', size: 'sm', variant: 'secondary', onPress: function () { moveSection(section.id, 1) } })),
				  )
				: null,
			h(Design.Text, { variant: 'text-md/semibold' }, 'Color'),
			h(
				RN.View,
				{ style: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 } },
				PRESETS.map(function (hex) {
					return h(
						RN.Pressable,
						{ key: hex, onPress: function () { pick(hex) } },
						h(RN.View, { style: { width: 30, height: 30, borderRadius: 15, backgroundColor: hex, borderWidth: color === hex ? 3 : 0, borderColor: '#ffffff' } }),
					)
				}),
			),
			h(Design.Text, { variant: 'text-md/semibold' }, 'Pick any color'),
			h(
				RN.View,
				{ style: { gap: 8 } },
				h(
					RN.View,
					{ style: { flexDirection: 'row', height: 34, borderRadius: 10, overflow: 'hidden' } },
					HUES.map(function (hv) {
						var on = Math.abs(hv - hue) < 8 || Math.abs(hv - hue) > 352
						return h(RN.Pressable, { key: 'hue' + hv, style: { flex: 1 }, onPress: function () { hueState[1](hv) } }, h(RN.View, { style: { flex: 1, backgroundColor: hslToHex(hv, 100, 50), borderBottomWidth: on ? 6 : 0, borderBottomColor: '#ffffff' } }))
					}),
				),
				h(
					RN.View,
					{ style: { borderRadius: 10, overflow: 'hidden' } },
					SHADES.map(function (sh) {
						return h(
							RN.View,
							{ key: 'row' + sh[0], style: { flexDirection: 'row', height: 30 } },
							[100, 80, 60, 40, 20, 0].map(function (sat) {
								var hex = hslToHex(hue, Math.round(sh[1] * sat / 100), sh[0])
								var on = hex === color
								return h(RN.Pressable, { key: 'c' + sat, style: { flex: 1 }, onPress: function () { colorState[1](hex); hexState[1](hex) } }, h(RN.View, { style: { flex: 1, backgroundColor: hex, borderWidth: on ? 3 : 0, borderColor: '#ffffff' } }))
							}),
						)
					}),
				),
			),
			h(
				RN.View,
				{ style: { flexDirection: 'row', alignItems: 'center', gap: 12 } },
				h(RN.View, { style: { width: 44, height: 44, borderRadius: 8, backgroundColor: cleanColor(hexState[0]) || '#000000' } }),
				h(RN.View, { style: { flex: 1 } }, h(Design.TextInput, { label: 'Or type a color code', placeholder: '#00d4ff', size: 'md', value: hexState[0], onChange: function (v) { hexState[1](v); var c = cleanColor(v); if (c) { colorState[1](c); hueState[1](hexToHue(c)) } } })),
			),
		)
	}
	function openEditSection(section) { openSheet(EDIT_KEY, EditSection, { section: section }) }

	/** What to do with one chat: pin it into a section, move it, or unpin it. */
	function ChatMenu(props) {
		var Design = valenced.discord.design.Design
		var id = props.id
		var state = read()
		var pinned = state.pins.indexOf(id) >= 0
		var current = state.assign[id] || ''
		function close() { try { sheets().hideActionSheet(MENU_KEY) } catch (e) {} }
		function row(label, sub, onPress) { return h(Design.TableRow, { key: label + sub, label: label, subLabel: sub, onPress: onPress }) }
		var rows = []
		rows.push(row(pinned ? (current ? 'Keep pinned, no section' : 'Pinned, no section') : 'Pin to the top', 'Without a section', function () { pin(id, ''); toast('Pinned'); close() }))
		state.sections.forEach(function (s) { rows.push(row((current === s.id ? '✓ ' : '') + s.name, 'Pin into this section', function () { pin(id, s.id); toast('Pinned in ' + s.name); close() })) })
		if (pinned) {
			rows.push(row('Move up', 'Within its group', function () { moveIn(id, -1) }))
			rows.push(row('Move down', 'Within its group', function () { moveIn(id, 1) }))
			rows.push(row('Unpin', 'Back to the normal list', function () { unpin(id); toast('Unpinned'); close() }))
		}
		return h(SheetBody, null, h(Design.Text, { variant: 'heading-lg/bold', numberOfLines: 2 }, channelLabel(id)), h(Design.TableRowGroup, null, rows))
	}
	function openChatMenu(id) { openSheet(MENU_KEY, ChatMenu, { id: id }) }

	// ---- Diagnostics you can copy ------------------------------------------------------------------
	function describe(v, depth) {
		try {
			if (v === null) return 'null'
			if (v === undefined) return 'undef'
			if (typeof v === 'string') return '"' + v.slice(0, 14) + '"'
			if (typeof v === 'number' || typeof v === 'boolean') return String(v)
			if (typeof v === 'function') return 'fn' + (v.name ? ':' + v.name : '')
			if (Array.isArray(v)) {
				var first = v[0]
				var inner = ''
				if (first && typeof first === 'object' && !Array.isArray(first)) inner = '{' + Object.keys(first).slice(0, 8).join(',') + '}'
				else if (first !== undefined) inner = describe(first, 2)
				return 'list' + v.length + (inner ? '[' + inner + ']' : '')
			}
			if (typeof v === 'object') {
				if (v.$$typeof) return 'element:' + (nameOf(v) || (typeof v.type === 'string' ? v.type : '?'))
				var keys = Object.keys(v)
				if (depth >= 1) return '{' + keys.slice(0, 8).join(',') + '}'
				return '{' + keys.slice(0, 12).map(function (k) { return k + '=' + describe(v[k], 1) }).join(', ') + '}'
			}
			return typeof v
		} catch (e) { return '?' }
	}
	var WATCH = { Messages: 1, MessagesHeader: 1, MessagesFastestList: 1, MessagesItemChannelFast: 1, FastestList: 1, FastestListChildren: 1, _FastListItemRenderer: 1, _FastListSectionRenderer: 1, _FastListSpacer: 1, MessagesItemHappeningNow: 1 }
	var collecting = false
	/** Remember what the pieces of the DM tab are given, and in what order they are made. */
	function noteElements(el) {
		try {
			var name = nameOf(el)
			if (!name) return
			if (name === 'Messages') collecting = true
			if (WATCH[name] && !status.detail[name]) {
				var props = el.props || {}
				status.detail[name] = Object.keys(props).slice(0, 40).map(function (k) { return k + ':' + describe(props[k], 0) }).join('; ')
				changed()
			}
			if (collecting && status.order.length < 160 && status.order.indexOf(name) < 0) status.order.push(name)
		} catch (e) {}
	}
	function buildReport() {
		var lines = []
		lines.push('Pin DMs report')
		lines.push('version: ' + VERSION)
		var state = read()
		lines.push('pins: ' + state.pins.length + ', sections: ' + state.sections.length)
		lines.push('hooked: ' + status.hooks.join(', '))
		lines.push('strip: shown ' + status.strip + ', slot ' + (status.voiceAnchor || 'top') + ', last tap ' + (status.lastOpen || '-'))
		lines.push('hold menu: replaced ' + status.pinSheets + ' time(s); sheet keys: ' + status.sheetKeys.join(', ') + '; native pin row: ' + (status.pinRow || 'not seen'))
		lines.push('label rows drawn: ' + status.labelRows + ', heading rows drawn: ' + status.hdRows + (status.error ? ', note: ' + status.error : ''))
		lines.push('list props reordered: ' + (status.listKey.join(', ') || 'none'))
		Object.keys(status.activity).forEach(function (m) {
			var a = status.activity[m]
			lines.push('activity ' + m + ': ' + a.calls + ' calls, ' + a.len + ' entries, ' + a.pins + ' pinned, moved ' + a.moved + (a.after ? ', ' + a.before + ' -> ' + a.after : ''))
		})
		Object.keys(status.detail).forEach(function (n) { lines.push('props of ' + n + ': ' + status.detail[n]) })
		lines.push('screens: ' + status.screens.join(', '))
		lines.push('voice-ish names: ' + status.cards.join(', '))
		lines.push('voice candidates: ' + status.voiceCards.join(' | '))
		lines.push('long lists: ' + status.rowLists.join(' | '))
		lines.push('shapes: ' + status.shapes.join(' | '))
		lines.push('creation order: ' + status.order.join(' > '))
		return lines.join('\n')
	}
	function copyReport() {
		try {
			valenced.externals.ReactNativeClipboard.Clipboard.setString(buildReport())
			toast('Report copied. Paste it in the chat.')
		} catch (e) { toast('Could not copy') }
	}

	// ---- The pinned strip, above the DM tab ----------------------------------------------------------
	var anchorSeenAt = 0
	function stripBelow() {
		try { return !!(storage && storage.cache && storage.cache.stripBelow2 === true) } catch (e) { return false }
	}
	function stripEnabled() {
		// Off unless switched on. The saved switch moved to stripOn3 in 1.16.4, so a strip switched on long ago (or settings
		// that have not loaded yet) no longer puts it above the DM list.
		try { return !!(storage && storage.cache && storage.cache.stripOn3 === true) } catch (e) { return false }
	}
	function openChat(id) {
		var f = finders()
		var done = ''
		function tryCall(propName, args) {
			try {
				var mod = f.lookupModule(f.filters.withProps(propName))[0]
				if (mod && typeof mod[propName] === 'function') { mod[propName].apply(mod, args); return true }
			} catch (e) {}
			return false
		}
		try {
			if (tryCall('transitionToChannel', [id])) done = 'transitionToChannel'
			else if (tryCall('selectPrivateChannel', [id])) done = 'selectPrivateChannel'
			else {
				var ch = stores().ChannelStore.getChannel(id)
				var uid = ch && ch.type === DM && ch.recipients && ch.recipients[0]
				if (uid && tryCall('openPrivateChannel', [uid])) done = 'openPrivateChannel'
			}
			if (!done) {
				var Linking = valenced.react.ReactNative.Linking
				Linking.openURL('https://discord.com/channels/@me/' + id)
				done = 'link'
			}
		} catch (e) { done = 'failed: ' + String((e && e.message) || e).slice(0, 40) }
		status.lastOpen = done
		changed()
	}
	function avatarUrl(id) {
		try {
			var ch = stores().ChannelStore.getChannel(id)
			if (!ch) return null
			if (ch.type === GROUP_DM) return ch.icon ? 'https://cdn.discordapp.com/channel-icons/' + id + '/' + ch.icon + '.png?size=64' : null
			var uid = ch.recipients && ch.recipients[0]
			var user = uid && stores().UserStore.getUser(uid)
			if (user && user.avatar) return 'https://cdn.discordapp.com/avatars/' + user.id + '/' + user.avatar + '.png?size=64'
		} catch (e) {}
		return null
	}
	function toggleFold(sectionId) {
		var state = read()
		var section = state.sections.filter(function (x) { return x.id === sectionId })[0]
		if (!section) return
		section.collapsed = !section.collapsed
		commit(state)
	}
	function StripRow(props) {
		var RN = valenced.react.ReactNative
		var Design = valenced.discord.design.Design
		var id = props.id
		var uri = avatarUrl(id)
		var label = channelLabel(id)
		var color = props.section ? props.section.color : '#80848e'
		return h(
			RN.Pressable,
			{ onPress: function () { openChat(id) }, onLongPress: function () { openChatMenu(id) }, style: { flexDirection: 'row', alignItems: 'center', gap: 10, height: 46, paddingRight: 14 } },
			h(RN.View, { style: { width: 4, alignSelf: 'stretch', marginVertical: 6, borderRadius: 2, backgroundColor: color } }),
			uri
				? h(RN.Image, { source: { uri: uri }, style: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#2b2d31' } })
				: h(RN.View, { style: { width: 32, height: 32, borderRadius: 16, backgroundColor: tint(color, 0.35), alignItems: 'center', justifyContent: 'center' } }, h(Design.Text, { variant: 'text-sm/bold' }, String(label).slice(0, 1).toUpperCase())),
			h(Design.Text, { variant: 'text-md/semibold', numberOfLines: 1, style: { flex: 1 } }, label),
			props.section ? h(RN.View, { style: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999, backgroundColor: tint(color, 0.22) } }, h(Design.Text, { variant: 'text-xs/bold', style: { color: color } }, String(props.section.name).toUpperCase())) : null,
		)
	}
	var SLOT_PRI = { top: 0, header: 1, voice: 2 }
	var slotShown = { top: 0, header: 0, voice: 0 }
	var slotOwner = {}
	function PinnedStrip(props) {
		var React = valenced.react.React
		var RN = valenced.react.ReactNative
		var Design = valenced.discord.design.Design
		var tick = React.useState(0)
		React.useEffect(function () {
			var update = function () { tick[1](function (n) { return n + 1 }) }
			listeners.push(update)
			return function () { listeners = listeners.filter(function (l) { return l !== update }) }
		}, [])
		var slot = (props && props.slot) || 'top'
		var inst = React.useRef(null)
		if (!inst.current) inst.current = {}
		React.useEffect(function () {
			if (slot === 'voice') return undefined
			var timer = setTimeout(function () { tick[1](function (n) { return n + 1 }) }, 4300)
			return function () { clearTimeout(timer) }
		}, [tick[0]])
		if (!stripEnabled()) return null
		if (slot !== 'top' && !stripBelow()) return null
		var now = Date.now()
		var names = ['top', 'header', 'voice']
		for (var q = 0; q < names.length; q++) {
			if (SLOT_PRI[names[q]] > SLOT_PRI[slot] && now - slotShown[names[q]] < 4000) return null
		}
		var owner = slotOwner[slot]
		if (owner && owner.ref !== inst.current && now - owner.at < 2500) return null
		slotOwner[slot] = { ref: inst.current, at: now }
		var firstShow = !slotShown[slot]
		slotShown[slot] = now
		if (slot !== 'top') status.voiceAnchor = slot
		if (firstShow && slot !== 'top') setTimeout(changed, 50)
		var state = read()
		var ordered = pinnedOrder(state.pins.slice())
		if (!ordered.length) return null
		status.strip++
		var groups = []
		var loose = ordered.filter(function (id) { return !sectionOf(state, id) })
		if (loose.length) groups.push({ section: null, ids: loose })
		state.sections.forEach(function (sec) {
			var ids = ordered.filter(function (id) { return state.assign[id] === sec.id })
			if (ids.length) groups.push({ section: sec, ids: ids })
		})
		var topInset = 0
		try { if (slot === 'top') topInset = (RN.Platform.OS === 'android' && RN.StatusBar && RN.StatusBar.currentHeight) || 0 } catch (e) {}
		var rows = []
		groups.forEach(function (g) {
			var folded = g.section && g.section.collapsed
			if (g.section) {
				rows.push(h(
					RN.Pressable,
					{ key: 'h' + g.section.id, onPress: function () { toggleFold(g.section.id) }, onLongPress: function () { openEditSection(g.section) }, style: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, height: 28 } },
					h(Design.Text, { variant: 'text-xs/bold', style: { color: g.section.color } }, (folded ? '▸ ' : '') + String(g.section.name).toUpperCase()),
					h(RN.View, { style: { flex: 1, height: 1.5, borderRadius: 1, backgroundColor: g.section.color, opacity: 0.5 } }),
				))
			} else if (groups.length > 1) {
				rows.push(h(RN.View, { key: 'h-loose', style: { paddingHorizontal: 16, height: 28, justifyContent: 'center' } }, h(Design.Text, { variant: 'text-xs/bold', color: 'text-muted' }, 'PINNED')))
			}
			if (!folded) g.ids.forEach(function (id) { rows.push(h(StripRow, { key: 'r' + id, id: id, section: g.section })) })
		})
		var maxH = Math.round(RN.Dimensions.get('window').height * 0.36)
		return h(
			RN.View,
			{ style: { paddingTop: slot === 'top' ? topInset : 4, paddingBottom: 6 } },
			h(RN.ScrollView, { style: { maxHeight: maxH }, nestedScrollEnabled: true, keyboardShouldPersistTaps: 'handled' }, rows),
		)
	}
	/** Diagnostics: elements that were given a voice channel, to find the voice channel card. */
	function noteVoiceCard(result) {
		try {
			if (status.voiceCards.length >= 4) return
			var props = result && result.props
			var t = result && result.type
			if (!props || !t || typeof t === 'string') return
			var keys = Object.keys(props)
			if (keys.length > 30) return
			for (var i = 0; i < keys.length; i++) {
				var v = props[keys[i]]
				if (v && typeof v === 'object' && !Array.isArray(v) && (v.type === 2 || v.type === 13) && typeof v.id === 'string' && (v.guild_id || v.guildId)) {
					var inner = t.type || t.render || t
					var name = t.displayName || t.name || (inner && (inner.displayName || inner.name)) || '?'
					var line = name + '.' + keys[i] + ' (' + keys.filter(function (k) { return k !== keys[i] }).slice(0, 6).join(',') + ')'
					if (status.voiceCards.indexOf(line) < 0) { status.voiceCards.push(line); changed() }
					return
				}
			}
		} catch (e) {}
	}
	function nameOf(el) {
		var t = el && el.type
		if (!t || typeof t === 'string') return ''
		var inner = t.type || t.render || t
		return t.displayName || t.name || (inner && (inner.displayName || inner.name)) || ''
	}
	// ---- Section headings inside the real list ---------------------------------------------------
	function hdOn() {
		try { return !storage || !storage.cache || storage.cache.hdOff !== true } catch (e) { return true }
	}
	var hdArmed = false
	/** If the app dies while headings are new, the next start turns them off by itself. */
	function armHeadingTrial() {
		if (hdArmed) return
		hdArmed = true
		try {
			Object.assign(storage.cache, { hdTrial: true })
			setTimeout(function () { try { Object.assign(storage.cache, { hdTrial: false }) } catch (e) {} }, 6000)
		} catch (e) {}
	}
	function headerEntry(kind) {
		return { channelId: 'pin-head:' + kind, lastMessageId: '0', isFavorite: false, isRequest: false, __pinHeader: true }
	}
	/** Pinned chats first, with a heading row in front of each section. Returns null when it cannot be done safely. */
	function withListHeaders(list, d) {
		var state = read()
		if (!state.pins.length || !hdOn() || !Array.isArray(d.sections)) return null
		var at = -1
		for (var i = 0; i < d.sections.length; i++) { if (d.sections[i] === d.channels.length && typeof d.sections[i] === 'number') { at = i; break } }
		if (at < 0) return null
		var out = []
		var shown = {}
		var restShown = false
		var anyPinned = false
		var loose = false
		list.forEach(function (entry) {
			var id = chatId(entry)
			var pinned = !!id && state.pins.indexOf(id) >= 0
			if (pinned) {
				anyPinned = true
				var sec = sectionOf(state, id)
				if (sec) {
					if (!shown[sec.id]) { shown[sec.id] = true; out.push(headerEntry(sec.id)) }
					if (sec.collapsed) return
				} else if (!loose) { loose = true; out.push(headerEntry('loose')) }
			} else if (id && anyPinned && !restShown) { restShown = true; out.push(headerEntry('rest')) }
			out.push(entry)
		})
		if (out.length === list.length) return null
		var sections = d.sections.slice()
		sections[at] = sections[at] + (out.length - d.channels.length)
		return { channels: out, sections: sections }
	}
	/**
	 * Spacing around a heading. The list gives every row the same height, so a heading row is as tall as a chat.
	 * To make it compact, the chats below a heading are drawn a little higher (they overlap the empty bottom of the heading row).
	 * gapAbove: space between the chat above and the heading text. gapBelow: space between the heading text and the chat below.
	 */
	var ROW = 55
	var ROW_PAD = 11
	var TEXT_H = 16
	function numSetting(key, fallback, min, max) {
		try {
			var v = storage && storage.cache && storage.cache[key]
			return typeof v === 'number' && v >= min && v <= max ? v : fallback
		} catch (e) { return fallback }
	}
	function gapAbove() { return numSetting('hdAbove2', 40, 11, 55) }
	/** Rows cannot be drawn higher (the list clips them), so the shift is always 0. */
	function gapShift() { return 0 }
	/** Compact labels: how far the chat under a label is moved down, so the label does not touch its name. */
	function labelClear() { return numSetting('hdClear', 6, 0, 16) }
	function gapTop() { return Math.max(0, gapAbove() - ROW_PAD) }
	function setGap(key, v, min, max) {
		try {
			Object.assign(storage.cache, (function (o) { o[key] = Math.max(min, Math.min(max, v)); return o })({}))
			fastCache = null
			refreshList()
			changed()
		} catch (e) {}
	}
	function resetGaps() {
		try {
			Object.assign(storage.cache, { hdAbove2: 40, hdClear: 6 })
			fastCache = null
			refreshList()
			changed()
		} catch (e) {}
	}
	/** Adds top padding to a row, whatever form its style takes. The row's content (centred) moves down by half of it. */
	function padStyle(style, pad) {
		var t = { paddingTop: pad }
		if (typeof style === 'function') return function (st) { var b = style(st); return Array.isArray(b) ? b.concat([t]) : [b, t] }
		if (Array.isArray(style)) return style.concat([t])
		return style ? [style, t] : t
	}
	/** Moves a row up by dy dp, whatever form its style takes. */
	function shiftStyle(style, dy) {
		if (!dy) return style
		var t = { transform: [{ translateY: -dy }] }
		if (typeof style === 'function') return function (st) { var b = style(st); return Array.isArray(b) ? b.concat([t]) : [b, t] }
		if (Array.isArray(style)) return style.concat([t])
		return style ? [style, t] : t
	}
	/** 'compact' (default): the heading is a small label inside the first chat of each section, so no extra rows. 'rows': a full heading row. */
	function compactOn() {
		try { return !storage || !storage.cache || storage.cache.hdStyle2 !== 'rows' } catch (e) { return true }
	}
	/** Compact mode: a folded section keeps its first chat (it carries the label) and hides the rest. Null when nothing changes. */
	function withCompactFold(list, d) {
		var state = read()
		if (!state.sections.some(function (x) { return x.collapsed }) || !hdOn() || !Array.isArray(d.sections)) return null
		var at = -1
		for (var i = 0; i < d.sections.length; i++) { if (d.sections[i] === d.channels.length && typeof d.sections[i] === 'number') { at = i; break } }
		if (at < 0) return null
		// A folded section becomes one heading row in place of its chats (none of them stay in view).
		var seen = {}
		var out = []
		list.forEach(function (entry) {
			var id = chatId(entry)
			var sec = id && state.pins.indexOf(id) >= 0 ? sectionOf(state, id) : undefined
			if (!sec || !sec.collapsed) { out.push(entry); return }
			if (seen[sec.id]) return
			seen[sec.id] = true
			out.push(headerEntry(sec.id))
		})
		if (!Object.keys(seen).length) return null
		if (out.length === list.length) return null
		var sections = d.sections.slice()
		sections[at] = sections[at] + (out.length - d.channels.length)
		return { channels: out, sections: sections }
	}
	/** Which row carries which label: the first chat of each section, the first loose pin, the first normal chat. */
	function computeLabels(list) {
		var state = read()
		var labels = {}
		var seen = {}
		var anyPinned = false
		var restDone = false
		var looseDone = false
		list.forEach(function (entry) {
			if (entry && entry.__pinHeader) { anyPinned = true; return }
			var id = chatId(entry)
			if (!id) return
			var pinned = state.pins.indexOf(id) >= 0
			if (pinned) {
				anyPinned = true
				var sec = sectionOf(state, id)
				if (sec && !seen[sec.id]) { seen[sec.id] = true; labels[id] = sec.id }
				else if (!sec && !looseDone) { looseDone = true; labels[id] = 'loose' }
			} else if (anyPinned && !restDone) { restDone = true; labels[id] = 'rest' }
		})
		return labels
	}
	/**
	 * Discord keeps a chat row as it was drawn, so a label or stripe on it would keep an old name or colour after the section
	 * is renamed. These redraw themselves when the sections or pins change.
	 */
	function useSectionsWatch() { useWatch(function () { var st = read(); return JSON.stringify([st.sections, st.assign, st.pins]) }) }
	/** Draws the piece again when keyOf() gives something new after a change. */
	function useWatch(keyOf) {
		var React = valenced.react.React
		var key = React.useState(keyOf)
		React.useEffect(function () {
			var live = true
			var update = function () {
				setTimeout(function () { if (!live) return; var k = keyOf(); key[1](function (old) { return old === k ? old : k }) }, 0)
			}
			listeners.push(update)
			return function () { live = false; listeners = listeners.filter(function (l) { return l !== update }) }
		}, [])
	}
	function SectionStripe(props) {
		useSectionsWatch()
		var RN = valenced.react.ReactNative
		var state = read()
		var section = state.pins.indexOf(props.chatId) >= 0 ? sectionOf(state, props.chatId) : undefined
		if (!section) return null
		return h(RN.View, { pointerEvents: 'none', style: { position: 'absolute', left: 0, top: 8, bottom: 8, width: 4, borderRadius: 2, backgroundColor: section.color } })
	}
	/** Which label each chat carries right now, from the list as last drawn and the pins and sections as they are now. */
	var liveCache = null
	function liveLabels() {
		try {
			var orig = fastCache && fastCache.orig
			if (!orig) return null
			var key = JSON.stringify(read())
			if (liveCache && liveCache.orig === orig && liveCache.key === key) return liveCache.labels
			var labels = computeLabels(reorderRows(orig))
			liveCache = { orig: orig, key: key, labels: labels }
			return labels
		} catch (e) { return null }
	}
	function CompactLabel(props) {
		useSectionsWatch()
		var RN = valenced.react.ReactNative
		var Design = valenced.discord.design.Design
		var state = read()
		var live = props.chatId ? liveLabels() : null
		var kind = live ? live[props.chatId] : props.kind
		if (!kind || !hdOn()) return null
		var sec = state.sections.filter(function (x) { return x.id === kind })[0]
		var name = sec ? sec.name : kind === 'loose' ? 'Pinned' : 'Direct messages'
		var color = sec ? sec.color : '#80848e'
		// Just the section's name; a folded section keeps a ▸ so its hidden chats are not lost.
		var label = (sec && sec.collapsed ? '▸ ' : '') + String(name).toUpperCase()
		return h(
			RN.Pressable,
			{ onPress: sec ? function () { toggleFold(sec.id) } : undefined, onLongPress: sec ? function () { openEditSection(sec) } : undefined, hitSlop: { top: 8, bottom: 6, left: 8, right: 8 }, style: { position: 'absolute', top: 0, left: 16, right: 16, height: 10, flexDirection: 'row', alignItems: 'center', gap: 6 } },
			h(Design.Text, { variant: 'text-xs/bold', numberOfLines: 1, style: { color: color, fontSize: 8, lineHeight: 9, flexShrink: 0, maxWidth: '80%' } }, label),
			h(RN.View, { style: { flex: 1, minWidth: 8, height: 1, backgroundColor: color, opacity: sec ? 0.5 : 0.3 } }),
		)
	}
	/** How many heading rows sit above each row (a heading counts the ones before it, a chat counts the one above it too). */
	function positionMap(channels) {
		var map = {}
		var count = 0
		channels.forEach(function (entry) {
			if (entry.__pinHeader) { map[entry.channelId] = count; count++ } else map[entry.channelId] = count
		})
		return map
	}
	function ListHeader(props) {
		useSectionsWatch()
		var RN = valenced.react.ReactNative
		var Design = valenced.discord.design.Design
		var state = read()
		var kind = props.kind
		var sec = state.sections.filter(function (x) { return x.id === kind })[0]
		var name = sec ? sec.name : kind === 'loose' ? 'Pinned' : 'Direct messages'
		var color = sec ? sec.color : '#80848e'
		// Just the section's name; a folded section keeps a ▸ so its hidden chats are not lost.
		var label = (sec && sec.collapsed ? '▸ ' : '') + String(name).toUpperCase()
		return h(
			RN.Pressable,
			{ onPress: sec ? function () { toggleFold(sec.id) } : undefined, onLongPress: sec ? function () { openEditSection(sec) } : undefined, style: { height: ROW, paddingHorizontal: 16, justifyContent: compactOn() ? 'center' : 'flex-start', paddingTop: compactOn() ? 0 : gapTop(), transform: props.shift ? [{ translateY: -props.shift }] : undefined } },
			h(
				RN.View,
				{ style: { flexDirection: 'row', alignItems: 'center', gap: 8 } },
				h(Design.Text, { variant: 'text-xs/bold', style: { color: color } }, label),
				h(RN.View, { style: { flex: 1, height: 1.5, borderRadius: 1, backgroundColor: color, opacity: sec ? 0.55 : 0.3 } }),
			),
		)
	}
	/** The row the list asks for a heading: draw the heading instead of a chat. */
	function decorateHeaderRow(result) {
		try {
			if (nameOf(result) !== 'MessagesItemChannelFast') return result
			var id = result.props && result.props.channelId
			if (typeof id !== 'string') return result
			// A chat row: give it a key that changes with every pin or section change, so Discord draws it again with the
			// new labels, stripes and spacing instead of keeping the row it drew before.
			if (id.indexOf('pin-head:') !== 0) return rowVersion ? valenced.react.React.cloneElement(result, { key: String(result.key == null ? id : result.key) + '~pin' + rowVersion }) : result
			status.hdRows++
			var before = fastCache && fastCache.pos ? fastCache.pos[id] || 0 : 0
			return valenced.react.React.createElement(ListHeader, { key: result.key, kind: id.slice(9), shift: gapShift() * before })
		} catch (e) {
			return result
		}
	}

	/** The real DM list ("MessagesFastestList"): note what it is given, and put the pinned chats first in any list it holds. */
	var fastCache = null
	/**
	 * The DM list only draws again when Discord's own data changes. Folding a section changes nothing of Discord's, so the
	 * list is wrapped in a piece that draws it again whenever a pin, a section or a setting changes.
	 */
	function decorateFast(result) {
		try {
			if (nameOf(result) !== 'MessagesFastestList') return result
			if (result.props && (result.props.__pinFast || result.props.__pinWrapped)) return result
			return h(FastWrap, { key: result.key, el: result })
		} catch (e) {
			return result
		}
	}
	function settingsKey() {
		try { return JSON.stringify(storage && storage.cache) || '' } catch (e) { return '' }
	}
	function FastWrap(props) {
		useWatch(settingsKey)
		var out = decorateFastInner(props.el)
		return out === props.el ? valenced.react.React.cloneElement(props.el, { __pinWrapped: true }) : out
	}
	function decorateFastInner(result) {
		try {
			var props = result.props || {}
			var keys = Object.keys(props)
			if (!status.fastList) {
				status.fastList = keys.slice(0, 24).map(function (k) {
					var v = props[k]
					return k + ':' + (Array.isArray(v) ? 'list' + v.length : typeof v === 'object' && v ? 'obj' : typeof v)
				}).join(', ')
				changed()
			}
			if (props.__pinFast) return result
			var state = read()
			if (!state.pins.length) return result
			var next = { __pinFast: true }
			var any = false
			// The DM tab hands the chats over as data.channels: [{ channelId, lastMessageId, ... }]. Pinned ones go first.
			// Discord's own pinned DMs come separately (data.channelFavorites); they are merged in, see mergeFavorites.
			var d0 = props.data
			var d = d0 && typeof d0 === 'object' && !Array.isArray(d0) ? mergeFavorites(d0) : d0
			if (d && typeof d === 'object' && !Array.isArray(d) && Array.isArray(d.channels) && d.channels.length > 1) {
				var stateKey = JSON.stringify(state) + '|' + compactOn() + hdOn() + nativeOn()
				if (!(fastCache && fastCache.orig === d.channels && fastCache.key === stateKey)) {
					var orderedCh = reorderRows(d.channels)
					var withHd = null
					var compact = compactOn()
					try { withHd = compact ? withCompactFold(orderedCh, d) : withListHeaders(orderedCh, d) } catch (e) { withHd = null }
					var finalList = withHd ? withHd.channels : orderedCh
					var labels = null
					try { labels = compact && hdOn() ? computeLabels(finalList) : null } catch (e) { labels = null }
					if (withHd || labels) armHeadingTrial()
					fastCache = { orig: d.channels, key: stateKey, data: withHd ? Object.assign({}, d, withHd) : orderedCh === d.channels ? d : Object.assign({}, d, { channels: orderedCh }), moved: !!withHd || orderedCh !== d.channels || d !== d0, headings: !!withHd && !compact, labels: labels, pos: withHd && !compact ? positionMap(withHd.channels) : null }
				}
				if (fastCache.moved) {
					next.data = fastCache.data
					any = true
					if (status.listKey.indexOf('fast.data.channels') < 0) { status.listKey.push('fast.data.channels'); changed() }
					if ((fastCache.headings || fastCache.labels) && status.listKey.indexOf('headings') < 0) { status.listKey.push('headings'); changed() }
				}
			}
			keys.forEach(function (k) {
				var v = props[k]
				if (!Array.isArray(v) || v.length < 2) return
				var ids = v.map(chatId).filter(Boolean)
				if (ids.length < 2 || ids.length < v.length * 0.5 || !distinctIds(ids)) return
				var ordered = hideOn() ? v.filter(function (e) { var id = chatId(e); return !(id && state.pins.indexOf(id) >= 0) }) : reorderRows(v)
				if (ordered !== v && ordered.length !== undefined && (ordered.length !== v.length || !hideOn())) { next[k] = ordered; any = true; if (status.listKey.indexOf('fast.' + k) < 0) { status.listKey.push('fast.' + k); changed() } }
			})
			return any ? valenced.react.React.cloneElement(result, next) : result
		} catch (e) {
			return result
		}
	}
	/** The header of the DM tab (title, search, Add Friends): the strip goes right under it. */
	function wrapHeader(result) {
		try {
			if (nameOf(result) !== 'MessagesHeader') return result
			if (!stripEnabled() || !stripBelow()) return result
			if (result.props && result.props.__pinStrip) return result
			var React = valenced.react.React
			var RN = valenced.react.ReactNative
			return React.createElement(RN.View, { key: result.key }, React.cloneElement(result, { __pinStrip: true }), React.createElement(PinnedStrip, { key: 'pin-strip-h', slot: 'header' }))
		} catch (e) {
			return result
		}
	}

	var VOICE_BAD = /avatar|item|icon|text|button|participant|user|name|status|indicator|speaker|tile|pill|badge|image|stack|member|label|wave|state|controls?|channelname/i
	/** The voice channel card itself, found by its name. The strip goes right under it. */
	function wrapVoiceCard(result) {
		try {
			var name = nameOf(result)
			if (!name) return result
			if (/voice|stage|carousel|call/i.test(name) && status.cards.length < 14 && status.cards.indexOf(name) < 0) { status.cards.push(name); changed() }
			if (!/voice/i.test(name) || VOICE_BAD.test(name)) return result
			if (!/(card|cards|carousel|rail|section|banner|panel|list|row)$/i.test(name)) return result
			if (!stripEnabled() || !stripBelow()) return result
			if (result.props && result.props.__pinStrip) return result
			var React = valenced.react.React
			var RN = valenced.react.ReactNative
			return React.createElement(RN.View, { key: result.key }, React.cloneElement(result, { __pinStrip: true }), React.createElement(PinnedStrip, { key: 'pin-strip-v', slot: 'voice' }))
		} catch (e) {
			return result
		}
	}
	/** The row of voice channel cards: the strip goes right under it. */
	function wrapVoice(result) {
		try {
			var props = result && result.props
			if (!props || !Array.isArray(props.data) || !props.data.length || typeof props.renderItem !== 'function') return result
			var first = props.data[0]
			if (!first || typeof first !== 'object' || first.kind !== 'voice') return result
			if (props.__pinStrip) return result
			if (!stripEnabled() || !stripBelow()) return result
			var React = valenced.react.React
			var RN = valenced.react.ReactNative
			return React.createElement(RN.View, { key: result.key }, React.cloneElement(result, { __pinStrip: true }), React.createElement(PinnedStrip, { key: 'pin-strip-v', slot: 'voice' }))
		} catch (e) {
			return result
		}
	}
	/**
	 * Discord has two pieces called "Messages": the DM tab (given only a style) and the message list inside every chat
	 * (displayName "Messages", given the channel and its messages). Only the DM tab gets the strip.
	 */
	function isDmTabMessages(t, props) {
		var inner = t.type || t.render || t
		if ((inner && inner.displayName === 'Messages') || t.displayName === 'Messages') return false
		if (props && typeof props === 'object') {
			var chatKeys = ['channel', 'channelId', 'messages', 'interactionStates', 'guildId']
			for (var i = 0; i < chatKeys.length; i++) if (chatKeys[i] in props) return false
		}
		return true
	}
	/** Puts the strip above the whole Messages screen. */
	function wrapMessages(result) {
		try {
			var t = result && result.type
			if (!t || typeof t === 'string') return result
			var inner = t.type || t.render || t
			var name = t.displayName || t.name || (inner && (inner.displayName || inner.name)) || ''
			if (status.screens.length < 8 && /messages|private|dms?$|home/i.test(name) && status.screens.indexOf(name) < 0) { status.screens.push(name); changed() }
			if (name !== 'Messages' || !stripEnabled()) return result
			if (result.props && result.props.__pinStrip) return result
			if (!isDmTabMessages(t, result.props)) return result
			// With the strip under the header, the header puts it there; a second one on top would double it.
			if (stripBelow()) return result
			var React = valenced.react.React
			var RN = valenced.react.ReactNative
			return React.createElement(RN.View, { key: result.key, style: { flex: 1 } }, React.createElement(PinnedStrip, { key: 'pin-strip' }), React.cloneElement(result, { __pinStrip: true }))
		} catch (e) {
			return result
		}
	}

	// ---- Section headers in the DM list --------------------------------------------------------------
	function SectionHeader(props) {
		var Design = valenced.discord.design.Design
		var RN = valenced.react.ReactNative
		var s = props.section
		var rest = !!s.rest
		var line = { flex: 1, height: 2, borderRadius: 1, backgroundColor: s.color, opacity: rest ? 0.35 : 0.75 }
		return h(
			RN.Pressable,
			rest ? {} : { onPress: function () { toggleCollapsed(s.id) }, onLongPress: function () { openEditSection(s) }, delayLongPress: 350 },
			h(
				RN.View,
				{ style: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10 } },
				h(RN.View, { style: line }),
				h(Design.Text, { variant: 'text-md/bold', style: { color: s.color, marginHorizontal: 12, letterSpacing: 1 } }, String(s.name).toUpperCase()),
				h(RN.View, { style: line }),
				rest ? null : h(Design.Text, { variant: 'text-md/bold', style: { color: s.color, marginLeft: 10 } }, s.collapsed ? '▸' : '▾'),
			),
		)
	}

	/** Puts the pinned chats first among the chats of a list, leaving every other row where it was. */
	function reorderRows(data) {
		var state = read()
		if (!state.pins.length) return data
		var slots = []
		var entries = []
		data.forEach(function (entry, i) {
			var id = chatId(entry)
			if (id) { slots.push(i); entries.push(entry) }
		})
		if (entries.length < 2) return data
		var ids = entries.map(chatId)
		if (!distinctIds(ids)) return data
		var first = pinnedOrder(ids)
		if (!first.length) return data
		var byId = {}
		entries.forEach(function (entry) { byId[chatId(entry)] = entry })
		var chosen = {}
		first.forEach(function (id) { chosen[id] = 1 })
		var ordered = first.map(function (id) { return byId[id] }).concat(entries.filter(function (entry) { return !chosen[chatId(entry)] }))
		var same = ordered.every(function (entry, i) { return entry === entries[i] })
		if (same) return data
		var out = data.slice()
		slots.forEach(function (slot, i) { out[slot] = ordered[i] })
		status.reordered++
		return out
	}

	/** The same list with a header in front of each section, and a folded section's chats left out. */
	function withHeaders(data) {
		var state = read()
		if (!state.sections.length) return data
		var out = []
		var shown = {}
		var restShown = false
		var anyPinned = false
		data.forEach(function (entry) {
			var id = chatId(entry)
			var pinnedHere = !!id && state.pins.indexOf(id) >= 0
			var section = pinnedHere ? sectionOf(state, id) : undefined
			if (pinnedHere) anyPinned = true
			if (id && !pinnedHere && anyPinned && !restShown) {
				restShown = true
				out.push({ __pinHeader: true, id: 'pin-section-rest', section: { id: 'rest', name: 'Direct messages', color: '#80848e', rest: true } })
			}
			if (section) {
				if (!shown[section.id]) {
					shown[section.id] = true
					out.push({ __pinHeader: true, id: 'pin-section-' + section.id, section: section })
				}
				if (section.collapsed) return
			}
			out.push(entry)
		})
		return out
	}

	/** Lists of rows whose entries hold a chat in a place this plugin does not know yet. Shown in the settings. */
	function noteUnmatched(props) {
		try {
			if (status.unmatched.length >= 3) return
			var state = read()
			var first = props.data[0]
			if (!first || typeof first !== 'object') return
			var text = JSON.stringify(first, function (k, v) { return typeof v === 'function' ? undefined : v }).slice(0, 2000)
			var hit = state.pins.some(function (id) { return text.indexOf(id) >= 0 })
			if (!hit) return
			var shape = Object.keys(first).slice(0, 8).join(', ')
			if (status.unmatched.indexOf(shape) < 0) { status.unmatched.push(shape); changed() }
		} catch (e) {}
	}

	var LIST_PROPS = ['data', 'items', 'rows', 'listData', 'channels', 'channelIds', 'privateChannelIds', 'dms']
	var scanned = typeof WeakSet === 'function' ? new WeakSet() : null

	function listProp(props) {
		for (var i = 0; i < LIST_PROPS.length; i++) {
			var list = props[LIST_PROPS[i]]
			if (Array.isArray(list) && list.length >= 2 && list.slice(0, 10).map(chatId).some(Boolean) && distinctIds(list.slice(0, 50).map(chatId))) return LIST_PROPS[i]
		}
		return null
	}

	/** Diagnostics: remember where an array holding a pinned chat shows up, in case it is not a list I know. */
	function scanShapes(el, props) {
		try {
			if (status.shapes.length >= 4 || !scanned) return
			var state = read()
			if (!state.pins.length) return
			var keys = Object.keys(props)
			if (keys.length > 40) return
			for (var i = 0; i < keys.length; i++) {
				var v = props[keys[i]]
				if (keys[i] === 'children' || !Array.isArray(v) || v.length < 4 || scanned.has(v)) continue
				scanned.add(v)
				var first = v[0]
				var text = typeof first === 'string' ? first : (first && typeof first === 'object') ? JSON.stringify(first, function (k, x) { return typeof x === 'function' ? undefined : x }).slice(0, 1500) : ''
				var found = state.pins.some(function (id) { return text.indexOf(id) >= 0 }) || v.slice(0, 20).some(function (e) { var t = typeof e === 'string' ? e : (e && typeof e === 'object') ? JSON.stringify(e, function (k, x) { return typeof x === 'function' ? undefined : x }).slice(0, 600) : ''; return state.pins.some(function (id) { return t.indexOf(id) >= 0 }) })
				if (!found) continue
				var tname = el && el.type && (el.type.displayName || el.type.name || (el.type.type && el.type.type.name) || (typeof el.type === 'string' ? el.type : '?'))
				var line = String(tname) + '.' + keys[i] + ' (' + (typeof first === 'object' && first ? Object.keys(first).slice(0, 6).join('/') : typeof first) + '; also: ' + keys.filter(function (k) { return k !== keys[i] }).slice(0, 8).join(',') + ')'
				if (status.shapes.indexOf(line) < 0) { status.shapes.push(line); changed() }
			}
		} catch (e) {}
	}

	/** Diagnostics: what the entries of a long list look like. */
	function noteRowList(el, props) {
		try {
			if (status.rowLists.length >= 4) return
			var list = props.data
			if (!Array.isArray(list) || list.length < 5 || typeof props.renderItem !== 'function') return
			var tname = el && el.type && (el.type.displayName || el.type.name || '?')
			var sample = list.slice(0, 2).map(function (e) {
				if (!e || typeof e !== 'object') return typeof e + ':' + String(e).slice(0, 12)
				return Object.keys(e).slice(0, 7).map(function (k) { var v = e[k]; return k + (typeof v === 'string' ? '=' + v.slice(0, 10) : typeof v === 'object' && v ? '{}' : '') }).join('/')
			}).join(' ; ')
			var line = tname + ' x' + list.length + ' [' + sample + ']'
			if (status.rowLists.indexOf(line) < 0) { status.rowLists.push(line); changed() }
		} catch (e) {}
	}

	/** Rows: a coloured stripe and a small section tag on each pinned chat. The row keeps its height, because the list sizes its rows itself. */
	function decorateRow(result) {
		try {
			var props = result && result.props
			if (!props || typeof props.onLongPress !== 'function' || !props.children || !result.type) return result
			var tn = result.type.displayName || result.type.name || ''
			if (!/Pressable/.test(tn)) return result
			var state = read()
			if (!state.pins.length) return result
			var id = deepId(props.children)
			if (!id) return result
			var React = valenced.react.React
			var RN = valenced.react.ReactNative
			var Design = valenced.discord.design.Design
			var headingsOn = hdOn() && fastCache && (fastCache.headings || fastCache.labels)
			var lab = hdOn() && fastCache && fastCache.labels ? fastCache.labels[id] : undefined
			var dy = 0
			var pinned = state.pins.indexOf(id) >= 0
			var section = pinned ? sectionOf(state, id) : undefined
			if (!section && !lab) return result
			if (!Array.isArray(props.children) && typeof props.children === 'function') return result
			var extra = []
			if (section) {
				status.rowHeaders++
				if (!status.headers) { status.headers = true; status.list = 'found, tags added'; changed() }
				extra.push(React.createElement(SectionStripe, { key: 'pin-stripe', chatId: id }))
				if (!headingsOn) {
					extra.push(React.createElement(
						RN.View,
						{ key: 'pin-tag', pointerEvents: 'none', style: { position: 'absolute', right: 10, bottom: 4, paddingHorizontal: 6, paddingVertical: 1, borderRadius: 999, backgroundColor: solid(section.color, 0.3) } },
						React.createElement(Design.Text, { variant: 'text-xs/bold', style: { color: section.color, fontSize: 10, lineHeight: 14 } }, String(section.name || '').toUpperCase()),
					))
				}
			}
			if (lab) extra.push(React.createElement(CompactLabel, { key: 'pin-label', kind: lab, chatId: id }))
			var kids = Array.isArray(props.children) ? props.children : [props.children]
			var patch = lab && labelClear() > 0 ? { style: padStyle(props.style, labelClear() * 2) } : {}
			if (lab) status.labelRows++
			return React.cloneElement(result, patch, kids.concat(extra))
		} catch (e) {
			return result
		}
	}

	/** Recognises the list the DM tab draws: it gets the pinned chats first, and the section headers. */
	function decorateList(result) {
		try {
			var props = result && result.props
			if (!props || typeof props !== 'object') return result
			var state = read()
			if (!state.pins.length) return result
			var key = listProp(props)
			if (!key) { scanShapes(result, props); noteRowList(result, props); return result }
			var list = props[key]
			if (list.some(function (e) { return e && e.__pinHeader })) return result
			var ids = list.map(chatId).filter(Boolean)
			if (ids.length < 2 || !distinctIds(ids)) return result
			if (ids.length < list.length * 0.5) return result
			status.lists++
			if (status.listKey.indexOf(key) < 0) { status.listKey.push(key); changed() }
			var ordered = reorderRows(list)
			var canHead = typeof props.renderItem === 'function' && key === 'data' && state.sections.length
			var data = canHead ? withHeaders(ordered) : ordered
			if (data === list) return result
			var next = {}
			next[key] = data
			if (canHead && data.some(function (e) { return e && e.__pinHeader })) {
				var original = props.renderItem
				next.renderItem = function (info) {
					var item = info && info.item
					if (item && item.__pinHeader) return h(SectionHeader, { section: item.section })
					return original.apply(this, arguments)
				}
				next.extraData = { original: props.extraData, sections: JSON.stringify(state.sections) }
				if (typeof props.keyExtractor === 'function') {
					var keyOf = props.keyExtractor
					next.keyExtractor = function (item) { return item && item.__pinHeader ? item.id : keyOf.apply(this, arguments) }
				}
				if (typeof props.getItemType === 'function') {
					var typeOf = props.getItemType
					next.getItemType = function (item) { return item && item.__pinHeader ? 'pin-section-header' : typeOf.apply(this, arguments) }
				}
				if (!status.headers) { status.headers = true; status.list = 'found, headers added'; changed() }
				status.headerLists++
			}
			return valenced.react.React.cloneElement(result, next)
		} catch (e) {
			return result
		}
	}

	// ---- The hold-down menu ------------------------------------------------------------------------
	function dmOf(props) {
		var keys = Object.keys(props)
		for (var i = 0; i < keys.length; i++) {
			var v = props[keys[i]]
			if (keys[i] === 'message') return undefined
			if (v && typeof v === 'object' && typeof v.id === 'string' && (v.type === DM || v.type === GROUP_DM)) return v.id
			if (typeof v === 'string' && /channel/i.test(keys[i]) && /^\d{15,}$/.test(v) && isDm(v)) return v
		}
	}

	function decorateMenu(result) {
		try {
			var props = result && result.props
			if (!props || !Array.isArray(props.items) || props.items.length < 2) return result
			var id = dmOf(props)
			if (!id) return result
			if (props.items.some(function (item) { return item && item.__pinDms })) return result
			var template = props.items.find(function (item) { return item && typeof item.label === 'string' })
			if (!template) return result
			var state = read()
			var pinned = state.pins.indexOf(id) >= 0
			var item = Object.assign({}, template, { label: pinned ? 'Unpin DM' : state.sections.length ? 'Pin DM…' : 'Pin DM', __pinDms: true })
			;['id', 'key', 'testID', 'nativeID', 'index', 'state'].forEach(function (n) { delete item[n] })
			var run = function () {
				try { sheets().hideAllActionSheets() } catch (e) {}
				setTimeout(function () {
					if (pinned) { unpin(id); toast('Unpinned') }
					else if (state.sections.length) openChatMenu(id)
					else { pin(id, ''); toast('Pinned to the top') }
				}, 0)
			}
			;['action', 'onPress', 'onSelect', 'onClick', 'callback', 'handler'].forEach(function (n) { if (n in template) item[n] = run })
			var icon = valenced.assets.getAssetIdByName('PinIcon')
			if (icon == null) icon = valenced.assets.getAssetIdByName('ic_pin')
			if (icon != null && 'iconSource' in template) item.iconSource = icon
			status.menus++
			changed()
			return valenced.react.React.cloneElement(result, { items: [item].concat(props.items) })
		} catch (e) {
			return result
		}
	}

	// ---- Discord's own Pin button in the hold-down menu: replaced by "Pin to <group>" ----------------
	var lastMenu = { id: '', at: 0, message: false }
	function pinHideOn() {
		try { return !storage || !storage.cache || storage.cache.pinHideOff !== true } catch (e) { return true }
	}
	function rememberMenu(props, key) {
		try {
			if (!props || typeof props !== 'object') return
			var id = dmOf(props)
			if (key && status.sheetKeys.length < 8 && status.sheetKeys.indexOf(String(key)) < 0) status.sheetKeys.push(String(key))
			if (id) lastMenu = { id: id, at: Date.now(), message: !!props.message }
		} catch (e) {}
	}
	/** Any piece made while the sheet opens that carries a DM channel tells us which chat it is for. The list's own rows do not count. */
	function noteMenuElement(el) {
		try {
			var name = nameOf(el)
			if (!name || /^MessagesItem|^MessagesFast|^MessagesHeader|^FastList|^_FastList|^Chat|^Guild|^HomeDrawer/.test(name)) return
			var props = el.props
			if (!props || typeof props !== 'object' || props.message) return
			var id = dmOf(props)
			if (id) lastMenu = { id: id, at: Date.now(), message: false }
		} catch (e) {}
	}
	function iconNameOf(row) {
		try { var ic = row && row.props && row.props.icon; return ic && typeof ic === 'object' ? nameOf(ic) : '' } catch (e) { return '' }
	}
	function isPinRow(row) {
		try {
			if (!row || typeof row !== 'object' || !row.props) return false
			if (/pin/i.test(iconNameOf(row))) return true
			var l = row.props.label
			return typeof l === 'string' && /^(un)?pin$/i.test(l.trim())
		} catch (e) { return false }
	}
	/** Labels only this plugin puts in the menu. */
	var OWN_LABEL = /^(✓ )?(Pin to .+|Pin \(no group\)|Pin to the top|Pin in Discord|Unpin in Discord)$/
	/** A row (or a piece wrapping one, a few levels down) made by this plugin. */
	function isOwnRow(el, depth) {
		depth = depth || 0
		try {
			if (!el || typeof el !== 'object' || depth > 3) return false
			if (Array.isArray(el)) return el.some(function (x) { return isOwnRow(x, depth) })
			var p = el.props
			if (!p) return false
			if (p.__pinDmsRow) return true
			if (typeof p.label === 'string' && OWN_LABEL.test(p.label.trim())) return true
			return isOwnRow(p.children, depth + 1)
		} catch (e) { return false }
	}
	function dotIcon(color) {
		return valenced.react.React.createElement(valenced.react.ReactNative.View, { style: { width: 22, height: 22, borderRadius: 11, backgroundColor: color } })
	}
	/** The group of rows that holds Discord's "Pin": swap it for one row per section of yours. */
	function decorateNativePin(result) {
		try {
			if (!pinHideOn()) return result
			var props = result && result.props
			if (!props || props.__pinGroup || !props.children) return result
			var rows = (Array.isArray(props.children) ? props.children : [props.children]).filter(function (r) { return r && typeof r === 'object' })
			if (!rows.length || rows.length > 3 || !rows.some(isPinRow)) return result
			// Discord wraps and rebuilds the rows of a group, and the marker on the rows made here can be lost on the way.
			// So a group that already holds one of this plugin's rows (by marker or by its text) is left alone.
			if (rows.some(isOwnRow)) return result
			var nativeRow = rows.filter(isPinRow)[0]
			if (!status.pinRow) { status.pinRow = nameOf(result) + ' > ' + nameOf(nativeRow) + ' ' + describe(nativeRow.props, 0); changed() }
			if (!lastMenu.id || Date.now() - lastMenu.at > 5000 || lastMenu.message) return result
			var id = lastMenu.id
			var React = valenced.react.React
			var state = read()
			var pinned = state.pins.indexOf(id) >= 0
			var current = state.assign[id] || ''
			var pinIcon = nativeRow.props.icon
			function close() { try { sheets().hideAllActionSheets() } catch (e) {} }
			function row(key, label, icon, run) {
				return React.createElement(nativeRow.type, Object.assign({}, nativeRow.props, { __pinDmsRow: true, key: key, label: label, icon: icon, subLabel: undefined, onPress: function () { close(); setTimeout(run, 0) } }))
			}
			var list = []
			state.sections.forEach(function (sec) {
				list.push(row('pin-' + sec.id, (pinned && current === sec.id ? '✓ ' : '') + 'Pin to ' + sec.name, dotIcon(sec.color), function () { pin(id, sec.id); toast('Pinned in ' + sec.name) }))
			})
			list.push(row('pin-none', (pinned && !current ? '✓ ' : '') + (state.sections.length ? 'Pin (no group)' : 'Pin to the top'), pinIcon, function () { pin(id, ''); toast('Pinned') }))
			if (pinned) list.push(row('pin-un', 'Unpin', pinIcon, function () { unpin(id); toast('Unpinned') }))
			// Discord's own Pin stays too, renamed, so a chat can still be pinned in Discord (it then sits at the top of its group).
			var nativeLabel = String(nativeRow.props.label || 'Pin')
			list.push(React.cloneElement(nativeRow, { key: 'pin-native', __pinDmsRow: true, label: /unpin/i.test(nativeLabel) ? 'Unpin in Discord' : 'Pin in Discord' }))
			status.pinSheets++
			changed()
			return React.cloneElement(result, { __pinGroup: true }, list)
		} catch (e) {
			return result
		}
	}

	function installElementHooks(cleanup) {
		var f = finders()
		var runtime = f.lookupModule(f.filters.withProps('jsx', 'jsxs'))[0] || valenced.react.ReactJSXRuntime
		function both(el) {
			if (globalThis.__pinDmsInstance !== INSTANCE) return el
			noteElements(el)
			noteMenuElement(el)
			var pg = decorateNativePin(el)
			if (pg !== el) return pg
			var hd = decorateHeaderRow(el)
			if (hd !== el) return hd
			return wrapMessages(wrapHeader(wrapVoiceCard(decorateFast(decorateRow(decorateList(decorateMenu(el))))))) }
		;['jsx', 'jsxs'].forEach(function (name) {
			if (runtime && typeof runtime[name] === 'function') cleanup(valenced.patcher.after(runtime, name, both))
		})
	}

	// ---- Settings ----------------------------------------------------------------------------------
	/** A small picture of a heading between two chats, drawn with the real spacing numbers. */
	function HeadingPreview(props) {
		var RN = valenced.react.ReactNative
		var Design = valenced.discord.design.Design
		var state = read()
		var sec = state.sections[0]
		var color = sec ? sec.color : '#3498db'
		var name = sec ? sec.name : 'Section'
		var shift = gapShift()
		var rowTop2 = ROW * 2 - shift
		function fakeRow(key, top, strong, down) {
			down = down || 0
			return h(
				RN.View,
				{ key: key, style: { position: 'absolute', left: 0, right: 0, top: top, height: ROW } },
				h(RN.View, { style: { position: 'absolute', left: 4, top: 8, bottom: 8, width: 4, borderRadius: 2, backgroundColor: strong ? color : '#80848e' } }),
				h(RN.View, { style: { position: 'absolute', left: 16, top: ROW_PAD + down, width: 32, height: 32, borderRadius: 16, backgroundColor: '#4e5058' } }),
				h(RN.View, { style: { position: 'absolute', left: 58, top: ROW_PAD + 3 + down, width: 90, height: 8, borderRadius: 4, backgroundColor: '#80848e' } }),
				h(RN.View, { style: { position: 'absolute', left: 58, top: ROW_PAD + 18 + down, width: 150, height: 6, borderRadius: 3, backgroundColor: '#4e5058' } }),
			)
		}
		if (compactOn()) {
			return h(
				RN.View,
				{ style: { height: ROW * 2, borderRadius: 14, backgroundColor: '#1e1f22', overflow: 'hidden' } },
				fakeRow('a', 0, false),
				fakeRow('b', ROW, true, labelClear()),
				h(
					RN.View,
					{ key: 'l', style: { position: 'absolute', top: ROW, left: 16, right: 16, height: 12, flexDirection: 'row', alignItems: 'center', gap: 6 } },
					h(Design.Text, { variant: 'text-xs/bold', style: { color: color, fontSize: 9, lineHeight: 11 } }, '▾ ' + String(name).toUpperCase() + '  1'),
					h(RN.View, { style: { flex: 1, height: 1, backgroundColor: color, opacity: 0.5 } }),
				),
			)
		}
		return h(
			RN.View,
			{ style: { height: rowTop2 + ROW, borderRadius: 14, backgroundColor: '#1e1f22', overflow: 'hidden' } },
			fakeRow('a', 0, false),
			h(
				RN.View,
				{ key: 'h', style: { position: 'absolute', left: 0, right: 0, top: ROW, height: ROW, paddingHorizontal: 16, paddingTop: gapTop() } },
				h(
					RN.View,
					{ style: { flexDirection: 'row', alignItems: 'center', gap: 8 } },
					h(Design.Text, { variant: 'text-xs/bold', style: { color: color } }, '▾ ' + String(name).toUpperCase() + '  1'),
					h(RN.View, { style: { flex: 1, height: 1.5, borderRadius: 1, backgroundColor: color, opacity: 0.55 } }),
				),
			),
			fakeRow('b', rowTop2, true),
		)
	}
	function Stepper(props) {
		var RN = valenced.react.ReactNative
		var Design = valenced.discord.design.Design
		return h(
			RN.View,
			{ style: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4 } },
			h(RN.View, { style: { flex: 1 } }, h(Design.Text, { variant: 'text-md/semibold' }, props.label), h(Design.Text, { variant: 'text-xs/medium', color: 'text-muted' }, props.sub)),
			h(Design.Button, { text: '−', size: 'sm', variant: 'secondary', onPress: props.onMinus }),
			h(RN.View, { style: { minWidth: 36, alignItems: 'center' } }, h(Design.Text, { variant: 'text-md/bold' }, String(props.value))),
			h(Design.Button, { text: '+', size: 'sm', variant: 'secondary', onPress: props.onPlus }),
		)
	}
	function Card(props) {
		var RN = valenced.react.ReactNative
		return h(RN.View, { style: { borderRadius: 14, padding: 14, gap: 10, backgroundColor: '#2b2d31' } }, props.children)
	}
	function SettingsComponent(props) {
		var React = valenced.react.React
		var Design = valenced.discord.design.Design
		var RN = valenced.react.ReactNative
		storage = props.api.jsonStorage
		storage.use()
		var tick = React.useState(0)
		var search = React.useState('')
		var tech = React.useState(false)
		React.useEffect(function () {
			var update = function () { tick[1](function (n) { return n + 1 }) }
			listeners.push(update)
			return function () { listeners = listeners.filter(function (l) { return l !== update }) }
		}, [])
		var state = read()
		var all = allDmIds()
		var q = String(search[0]).toLowerCase().trim()
		function dot(color) { return h(RN.View, { style: { width: 14, height: 14, borderRadius: 7, backgroundColor: color } }) }

		var sectionRows = state.sections.map(function (s) {
			var count = state.pins.filter(function (id) { return state.assign[id] === s.id }).length
			return h(Design.TableRow, {
				key: 'sec' + s.id,
				label: s.name,
				subLabel: count + ' chat' + (count === 1 ? '' : 's') + (s.collapsed ? ' · folded' : '') + ' · tap to edit or reorder',
				icon: dot(s.color),
				onPress: function () { openEditSection(s) },
			})
		})
		var pinnedRows = pinnedOrder(state.pins.slice()).map(function (id) {
			var s = sectionOf(state, id)
			return h(Design.TableRow, {
				key: 'pin' + id,
				label: channelLabel(id),
				subLabel: (s ? s.name : 'No section') + ' · tap for options',
				icon: s ? dot(s.color) : undefined,
				onPress: function () { openChatMenu(id) },
			})
		})
		var others = all.filter(function (id) { return state.pins.indexOf(id) < 0 && (!q || channelLabel(id).toLowerCase().indexOf(q) >= 0) }).slice(0, 60)
		var pinCount = state.pins.length
		var summary = pinCount + ' pinned chat' + (pinCount === 1 ? '' : 's') + ' in ' + state.sections.length + ' section' + (state.sections.length === 1 ? '' : 's')

		var technical = [
			h(Design.TableRow, { key: 'store', label: 'DM list order', subLabel: status.store + (status.hooks.length ? ' · hooked: ' + status.hooks.join(', ') : ' · not hooked') + ' · reordered ' + status.reordered + ' time(s)' }),
			h(Design.TableRow, { key: 'list', label: 'Section headings in the list', subLabel: (status.listKey.indexOf('headings') >= 0 ? 'Working' : 'Not seen yet') + ' · heading rows drawn: ' + status.hdRows }),
			h(Design.TableRow, { key: 'lk', label: 'List props I reordered', subLabel: status.listKey.length ? status.listKey.join(', ') : 'none yet' }),
			h(Design.TableRow, { key: 'activity', label: 'Hook activity', subLabel: Object.keys(status.activity).length ? Object.keys(status.activity).map(function (m) { var a = status.activity[m]; return m + ': ' + a.calls + ' calls, ' + a.len + ' entries, ' + a.pins + ' pinned, moved ' + a.moved }).join(' | ') : 'Nothing called yet. Open the Messages tab.' }),
			h(Design.TableRow, { key: 'stripstatus', label: 'Pinned strip', subLabel: (status.strip ? 'Shown ' + status.strip + ' time(s)' : 'Not shown') + (status.lastOpen ? ' · last tap: ' + status.lastOpen : '') }),
			h(Design.TableRow, { key: 'menu', label: 'Hold-down menu', subLabel: status.menus ? 'Added ' + status.menus + ' time(s)' : 'Not seen yet. Hold a DM in the list.' }),
			status.error ? h(Design.TableRow, { key: 'error', label: 'Problem', subLabel: status.error }) : null,
		]

		return h(
			RN.ScrollView,
			{ style: { flex: 1 }, contentContainerStyle: { paddingBottom: 38 }, keyboardShouldPersistTaps: 'handled' },
			h(
				Design.Stack,
				{ style: { paddingVertical: 20, paddingHorizontal: 12 }, spacing: 22 },
				h(
					Card,
					null,
					h(Design.Text, { variant: 'heading-lg/bold' }, 'Pin DMs ' + VERSION),
					h(Design.Text, { variant: 'text-sm/medium', color: 'text-muted' }, summary + '. Pinned chats sit at the top of Messages, in coloured sections you can fold.'),
					h(
						RN.View,
						{ style: { flexDirection: 'row', gap: 10 } },
						h(RN.View, { style: { flex: 1 } }, h(Design.Button, { text: 'New section', variant: 'primary', size: 'sm', onPress: function () { openEditSection(null) } })),
						h(RN.View, { style: { flex: 1 } }, h(Design.Button, { text: 'Copy report', variant: 'secondary', size: 'sm', onPress: copyReport })),
					),
				),
				h(
					Design.TableRowGroup,
					{ title: 'Sections' },
					sectionRows.length ? sectionRows : [h(Design.TableRow, { key: 'nosec', label: 'No sections yet', subLabel: 'Tap New section above, like Girls or Boys.' })],
				),
				h(
					Design.TableRowGroup,
					{ title: 'Pinned' },
					pinnedRows.length ? pinnedRows : [h(Design.TableRow, { key: 'none', label: 'Nothing pinned yet', subLabel: 'Hold a DM and choose Pin DM, or pick one below.' })],
				),
				h(
					Card,
					null,
					h(Design.Text, { variant: 'heading-md/bold' }, 'Section headings'),
					h(Design.Text, { variant: 'text-sm/medium', color: 'text-muted' }, compactOn()
						? 'Compact: a small coloured label sits on the first chat of each section, with no extra rows. Tap the label to fold, hold it to edit.'
						: 'Rows: a full heading row in front of each section. Press − or + to move the text inside the row.'),
					h(HeadingPreview, null),
					compactOn() ? h(Stepper, { label: 'Space under labels', sub: 'Moves the chat under a label down so the label does not touch its name.', value: labelClear(), onMinus: function () { setGap('hdClear', labelClear() - 1, 0, 16) }, onPlus: function () { setGap('hdClear', labelClear() + 1, 0, 16) } }) : null,
					compactOn() ? null : h(Stepper, { label: 'Heading position', sub: 'Plus puts more room above the heading and less below it. Minus does the opposite.', value: gapAbove(), onMinus: function () { setGap('hdAbove2', gapAbove() - 4, 11, 55) }, onPlus: function () { setGap('hdAbove2', gapAbove() + 4, 11, 55) } }),
					h(Design.Button, { text: 'Reset spacing', variant: 'secondary', size: 'sm', onPress: resetGaps }),
				),
				h(
					Design.TableRowGroup,
					{ title: 'Options' },
					h(Design.TableSwitchRow, { key: 'pinhide', label: 'Replace Discord\'s Pin button', subLabel: 'The hold-down menu of a DM shows Pin to each of your sections instead of Discord\'s own Pin.', value: pinHideOn(), onValueChange: function (v) { try { Object.assign(storage.cache, { pinHideOff: !v }); changed() } catch (e) {} } }),
					h(Design.TableSwitchRow, { key: 'compact', label: 'Compact headings', subLabel: 'Small labels inside the chats, no extra rows. Turn off for full heading rows.', value: compactOn(), onValueChange: function (v) { try { Object.assign(storage.cache, { hdStyle2: v ? 'compact' : 'rows' }); fastCache = null; refreshList(); changed() } catch (e) {} } }),
					h(Design.TableSwitchRow, { key: 'headings', label: 'Section headings in the list', subLabel: 'A heading row with fold in front of each section. If the app ever fails to start with it, it turns itself off.', value: hdOn(), onValueChange: function (v) { try { Object.assign(storage.cache, { hdOff: !v, hdTrial: false }); fastCache = null; refreshList() } catch (e) {} } }),
				),
				h(Design.TextInput, { label: 'Find a chat to pin', placeholder: 'Search your DMs', size: 'md', value: search[0], onChange: function (v) { search[1](v) } }),
				h(
					Design.TableRowGroup,
					{ title: 'Your DMs' },
					others.length
						? others.map(function (id) { return h(Design.TableRow, { key: 'o' + id, label: channelLabel(id), subLabel: 'Tap to pin', onPress: function () { state.sections.length ? openChatMenu(id) : pin(id, '') } }) })
						: [h(Design.TableRow, { key: 'empty', label: all.length ? 'No match' : 'No DMs found', subLabel: all.length ? 'Try another search.' : 'Open the DMs tab once so Discord loads the list, then come back.' })],
				),
				h(
					Design.TableRowGroup,
					{ title: 'Experimental' },
					h(Design.TableSwitchRow, { key: 'strip', label: 'Pinned strip above the DM tab', subLabel: 'Repeats your pinned chats in a panel at the top. Off by default.', value: stripEnabled(), onValueChange: function (v) { try { Object.assign(storage.cache, { stripOn3: !!v }); changed() } catch (e) {} } }),
					h(Design.TableSwitchRow, { key: 'stripbelow', label: 'Put the strip under the Messages header', subLabel: 'Only matters when the strip is on.', value: stripBelow(), onValueChange: function (v) { try { Object.assign(storage.cache, { stripBelow2: !!v }); changed() } catch (e) {} } }),
					h(Design.TableSwitchRow, { key: 'nativeinto', label: "Put Discord's pinned DMs in the sections", subLabel: 'A chat pinned in Discord goes to the top of its section, or to the top of Direct messages, instead of above everything.', value: nativeOn(), onValueChange: function (v) { try { Object.assign(storage.cache, { nativeInto: !!v }); favCache = null; fastCache = null; refreshList() } catch (e) {} } }),
					h(Design.TableSwitchRow, { key: 'hidepinned', label: 'Hide pinned chats from other lists', subLabel: 'Leaves them out of the normal DM lists the plugin can reach.', value: hideOn(), onValueChange: function (v) { try { Object.assign(storage.cache, { hidePinned2: !!v }); refreshList() } catch (e) {} } }),
				),
				h(
					Design.TableRowGroup,
					{ title: 'Diagnostics' },
					h(Design.TableRow, { key: 'copyreport', label: 'Copy diagnostic report', subLabel: 'Open the Messages tab first, then tap here and paste it to the developer.', onPress: copyReport }),
					h(Design.TableSwitchRow, { key: 'tech', label: 'Show technical details', value: tech[0], onValueChange: function (v) { tech[1](!!v) } }),
					tech[0] ? technical : null,
				),
			),
		)
	}

	Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
	exports.default = plugin({
		jsonStorage: { load: true, default: defaults },
		SettingsComponent: SettingsComponent,
		start: function (api) {
			globalThis.__pinDmsInstance = INSTANCE
			storage = api.jsonStorage
			try {
				if (storage.cache && storage.cache.hdTrial === true) { Object.assign(storage.cache, { hdOff: true, hdTrial: false }); status.error = 'Section headings were turned off: the app did not start with them.' }
			} catch (e) {}
			function attempt(label, step) { try { step() } catch (e) { status.error = label + ': ' + String((e && e.message) || e).slice(0, 70) } }
			attempt('store', function () { installStoreHooks(api.cleanup) })
			attempt('elements', function () { installElementHooks(api.cleanup) })
			api.cleanup(function () {
				memo = {}
				listeners = []
				try { sheets().hideActionSheet(EDIT_KEY) } catch (e) {}
				try { sheets().hideActionSheet(MENU_KEY) } catch (e) {}
				setTimeout(function () { try { var s = sortStore(); if (s && s.emitChange) s.emitChange() } catch (e) {} }, 0)
			})
			setTimeout(refreshList, 1500)
		},
	})
	return exports
})({})
