(function (exports) {
	/*
	 * Colorful Channels for Valenced.
	 * Based on the Colorful Channels module of NexxUtils for Revenge by nexpid (CC BY 4.0),
	 * https://github.com/nexpid/RevengePlugins. The channel icon pictures are from that plugin.
	 * Rewritten for Valenced. Keep `(function` as the first thing in this file: Valenced loads it
	 * as `return <file>`.
	 *
	 * Icon packs: with "Follow icon packs" on, the channel symbol is drawn from the same icon Discord
	 * uses for a plain channel of that type, and the lock, warning or controller is drawn from the
	 * pack's own lock, warning or controller icon. That way the symbol changes with whichever pack is
	 * picked in Themes > Icons. When the pack's icons can't be found, the built-in pictures are used.
	 */
	var defaults = { nsfwTag: true, colorIcons: true, colorIconsFallback: false, followPack: true }

	var IMAGES = {
		announcementLock: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAyJJREFUeF7tmzFoFEEUhr/YnHZXSmzORrBRFJHYCDYhpPAEG7URFRK4lFZaCDamEisDFprawiKFYtJZGQuLHNhYiNWVRiuTKjazYXzszNu7zM3s3s0HRy7/Lsfex+x7s7tzM7u7f8i4OSaDzP9kQQpZkEIWpJAFKWRBClmQQhakkAUpZEEKWZBCFqSQBSlkQQpZkEIWpFA3QXPAG2AH6MmNKZipwR3FOeA6cBeYtfI94IT1fxJSCeoAi8AycE5utJiRQWxiCmoDd4AuMC83Oph4QS1gwUi5DRyXOyhMrCBXXRmWiRLUAZYCSLFJLqhKm2+ZlrsD/AUOzN9nYr8N4FFAObVAG0Ed88XLOo1swwfW+1DUegS1PHIYoeA2Ep+gBx45sWjLIDY+QcsySECtBZ2RQQIWZRAbn6A61JiuDGLjE1QH5s2kMxl1FwTwLmUtaoKgWeBtKklNEIQ51T6lON18M+kqM2N7pltl/xBsmQnsB+C3eY2NJgoKzR7wAngsN5AFHSKvKw9pSg0aN845XxakkAUpZEEKPkF7MphGfIK+y2Aa8Ql6JYNpxCfoNdCX4bThE7Rv7se4JE1FjfIJAvgJXAZWjKhCSjE9n3h8lxrD0uRLDVyPmLQRNPXEEHQDWG9qzYpxihVDt1jp0QOu+i4QE1F6isUUZFN1AVVMyo4zmSCbOeCzDBNQepwxapDGkgzqREhBriLckoFFB7gnwzoRUtAvGRgWZGDhe7S8Cpw2r2KiGp2QNWjTsThzANwEtkXeBr45FlytA/dlaOrV0ojrHTVKa1BIQT3gpQwttoCvwBfglNLBrpQItSlWzPo+Y1jGLqgF/HCMiGHoA+dl6KEHPA8wokoFhaxB+4F+PvBEBgprwDVPkzgSIQVhnniuynAI1s1nDMs2cGsckkILwjyhXBnhYF2FuSobwEMZVsTZIcchCDPsz5ovPZAbBQMj9ChyCtZGHMHvZVAQski7aAEXgIvAJdPBsDraR1O/QtI1sqo0jC3zq4DSY4ghKBX23YOTZs2l3en6ZuQ8dclhwgUFYVw1aGLIghSyIIUsSCELUvgHwGunoc5i8wsAAAAASUVORK5CYII=',
		announcementWarning: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAA1FJREFUeF7tmjFPFEEUgD9sMLme7jQxMXRYQKUF0cLEQxsLsCBRKwgJsdJE/4CJVlIQqZTEQluiNBSnjZUUUmljYyUNMZFEKmzekvVlZ94utzuzcPM1HG8um+Vj5s2b3Teyt/ebhJszOpD4nyTIIAkySIIMkiCDJMggCTJIggySIIMkyCAJMkiCDJIggyTIIAkySIIM2iaoB7wGfgEbejAGIy14ojgJzAF3gTE1NgVsq1hQYgnqAvPAHWBCDwq7wAVgXw+EJKSgjkiZA67qwQIWgTUdDE3TgjrANDArs2VUf8HBDnBJB2PQlKCeSLlRkFfKED33ZNQpqAssO5JtFfrANR2MRZltvgMsAF+Bv8Ch/HymvvceeDigHIB3OhATawZ15Q8v2mkOgLO53w9znwfhHPBTB2PhE9QBPjvkZIzkPtclKH/N6PiW2LwhpwkOdCA2PkFLOhCAUVnWrcEnaFwHAtHTgZj4BJUt6uomxsx14hMUi4k2zaI2CgJ41ZZc1FZBY1J/RZfUVkHIUvsSe7n5CsUyhV8ThWIRO8CqCPsW8hnRSRHUJAfACvBID5AEHaHPlUe0OQeFxFnzJUEGSZBBEmTgE9S6Rw8x8An6rgPDiE/Qqg4MIz5Bb6SCHWp8gvaBmx5JQ5GjfIKQtwuX5TVwPyclK89PPb6jRlVO8lED19sUawYNPSEEzQDrJzVnhVhi2dTNOj0Wgeu+A2IkCpdYSEF5uvKkcCnCy0kXRfcZTVCeHvBBByNQeJ8hcpDFrA60iToFuZJwRwdydKWfqLXUKci1Vqd1IMe8DuR4Lq0wU8ATT0XfKHXmoA3glg5Kt2qvoKWuA/xwNFytA/d0UFqGlyv2O5alMAfVKWgBeKmDOfrAlnSqdY0dzOpRzDpmfdeoSuOCfDOiClU7XBeAFzXMqEJBdeagfeC+Dh6DxzpgsAZc8WwSA1GnIIBNSajHZV2uUZVt4HYTkuoWBPBUjhNVb9aVmMuyCTzQwZI4d8gmBCHT/qJs1bt6ULErQgeRk7F2zBn8Vgcy6kzSPiblgDoutc0faUL4CHxqoBmhJz1GZTaMvpQnhfcQSlAMslJgBjgv/5z8TrcjM2fFJYdTLqgWmspBp4YkyCAJMkiCDJIgg3/VAbWkCfiK6gAAAABJRU5ErkJggg==',
		controller: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAftJREFUeF7t2bFKW3EYhvFH6SaI2KVkUUFcHCvp5DUUegd2EsFZcgkujiVThe71BrwCxYwuvYDERa3DmXX5H4gfie9pMSd84f0t4Xw5x8Djl0OiS4+PT9h0y3Fgr2UP1AV6wG9gCNyUmdIt59bX9IDteBLAUtK3WBf4AXyOTwAV0Afuy/HH8jh+fAislONxA+AIuK4HGQMdAD/j8J19B85JGKgLXMXhjHwBrrPdg07iYIZOSLZBH4C/U+4ds1ABa5k2aLPFOJTX2swUaD8OWrCfKdBuHLRgN1OgrThowVamQBtx0IKNTIE6cdCGTIHmoZMp0GoctGA1U6A2PwPVVjIFmgsHEhxIyPRl9TkOprgo38TXy6fvT2V+B9wCD8Ap8C1cN9GiBaqAnfKn1Ld0gD9NbvyL9hbrN4hDOacfh5Ms0gY13Z5aoy3KtEGjOAiabk+tyRaNMgW6jIMxFXAWhw2clWunucwUqPfGFh3/4/bUhuXaSUZAL1OgIbAH/Br7rQ+Ar/W/aP7TefkZg3JcldfYA4aZbtJzkWmD5sKBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSHEhwIMGBBAcSXgBwxljfZ4m+xwAAAABJRU5ErkJggg==',
		forumLock: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAA/hJREFUeF7tmzFoFEEUhr9Y5RqLFIogJI0QUihYmLNIIaQ9bSSFVQIGS0GNhagIsVITEDujnLWdXhtIoWBynYJ6YJNU4hUG07ilzdsQn7sze7uzMxtvPwgH/8Lc3XezM7PzJiO7u7+oSeeIDmr+phZkoRZkoRZkoRZkYcTTLNYAZoFzwElgCpiQa0fldQ/4Ka9f5K8HrAO/D7TllTIFjQNzwGURk5cuMK1DX5QhqAUsyqsrJoAdHfrA5RjUBLaAt47ldEPJwZGgBtAGPhS8ldK4rgOfFBXUAraBeX3BER1gU4c+KSJoSW6nY/qCQ97owDd5Ba0Aj3RYAus68E0eQW3ghg5Loq8D3wwqaLnE8SaJYAvEmEEEtYC7OvzfySpoHHihw2Egq6BnJc9WlSWLoKbjlfGhIougpzoYJmyCmiU9PhwabIKu6WDYMG13NGQDa1Rf8MiIDnxj6kGzgeVUApOgoR57YkyCzuhgGDEJOqWDADR04BuToDEdBCD46t0kKC7HhOS0DnxjElRjEbSnA49EwEPZkw6KSdC2DjwQAavAJHBPXwyBSdAPHZRMR8TcDFkH05gEvdNBSfSBq8DFKomJCS2oJyv2l/pCVQj5sNqVww1Zek18EGJGFrBjskaKZDLZltMg76VUlKXNTJgEISWeMqoYPeBshqpFXCgY9LmwA6y5mAVtgppSc3dJX76w6Vduyk7moGI0Xant5y5fm8YgpOGuDgtyySJnCdhwIAdpY0PazIVNEI5PV6xafs22lLRdjnuj0mY7z8Ov7RaLcTEW9eUgVNq44+I9bLwCFnRoIksPAnggM0YR7hjkLHmQg7zHig5NZO1ByJfL2/VNvacp40TetvNw3nKr75O1By0X/ALPU+Qgs1WRtvOQeTzKImjZwaGFtLp+y9FsNSiTwBUdJmET5EJOzzCtF227CLd0kIRJkAs5GO718UC9J2ZSxj8jaYJcyUGej5KY00EAZnSgSRLk+qDUZx0I1g/nAetnSBK0qIOCfNeBUIWykvUzJAlyTdpBzCqUleJ/qEklSdCaDgoQGdY/VSgrWddfSYI6sgXa0xcGJAKe6PAAIasmMdbHp0EeNVzzVabakPSB4zo8SFIP8sU3HQRgSweakIJ8FAVsfNSBJqSg1zoIgHW3NKSgnSwfsGQ+6UATUhBSfw/JCR1oQgvqBO5F1lO8oQUhRQHreqQk5m1P9FUQtAnc16FHjLuLVRAE8FgqDiGYlIJCIiFX0kn4KP0kEYmof3Y+q9KDYhaA2wHGpNG0DbyqCUJutwuBZ7d9qigIGbin5VCVD1FR2sq+amNQGvH5oCmZluPzQUWJZDWdegLksAgKRlVvscpQC7LwB+4Oww67KFwLAAAAAElFTkSuQmCC',
		forumWarning: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAABC5JREFUeF7tm72LXFUYh59YbBNYsDGwxC0CVoElIbEIJkyw0cZJJduEDYRg/gBZUdAUNiuKVoKFIbBBCGk3lZ1LAiEfQ5I19iEMQiwcFdJMZfPOMv6895w7c8857w3MA9P8DlyGZ87He865c2A0+psF9bymwYL/shAUYSEowkJQhIWgCAcKrWLLwFngFLACHAUOAQftswSMgJfAC+A34ClwH3gE/KMPLEVOQavAun1OaOOMDICb9nmujTnJIagHfAx8oA0JGAMfAjvakIuUc1APeAj8kkkONhRPaZiTFIKWgW0T03YoxRgDP2iYk7aC+jahbmhDJr57leagTeBrDTMytNWv6Io2bw/aKiwH4MvScpizB20XHFITBsBJDUswaw/adJCDlQ0uzCKo7zCsAK4DuxqWoukQWwUeA69rQ2bGwFulV65pmvag7x3k4LGsK016UM+KwNK4LOtKkx70rQaFcFnWlZigXoHtQxUD4EcNPYgJuqhBIdyWdSU2B/3pMDm7FYVVhHpQz0EONvd0hpCg9zUoxGMNPAkJOqpBAcbedY8SErSiQQGWNPAmJOiIBoVY1sCTkKCDGhRiXQNPQoK8OK2BJyFBf2hQCI/SopaQoBcaFGDkuPerJCTodw0ycws45nk4VkVI0G0NMjECztmJZadqICKC7muQgaG91FDsKnlWQpvVZeBZxklzALzb8Mxn8iLEGStgj9j3GttiMnkj5A7wc8qeGBJExiuepnL6wJU5zqRuAVdT9MyYoDXgiYYtGQLvRH7lNeDaHGKUgZ1p7WlDU0JzEPbggYYtOR+Rswk8SCAHe8YDe+ZcxASR+HTvq8gyvm13byk3rUv2zG1taEITQbt2edeWod3p15FrvpuwMY+kJoIAvrAVow2hW4pSV9obkR/pf8Qm6WnanE8PgTc1NNZsnkg5rGKcjQz1fZr2oK0WcgB+0mCKa4XlYN+n0blTE0FbwKcazsgNDYx+otVqVg43PXeKCUohZxCoQ65oUJDLGlQREpRCDrYFqGLVqfdMOGHzX5A6QankYPujKhp18cy8p4FSJaifUA7APQ2MMxo4EP0OVYIuadCSvzQwPK6VlOMaKFWCUlMnyOtaaZo3NFCqBF3VoAWjQPXsda00TbT+qhK0A3xk1W8bxpGy/qUGDkS3T7NsNVLz0HmZJ7IFgpoeVIrStyZVPNJA8RRU6tYkRF0Ru4+noJsaOHBXA8VT0PMMx7mz8kwDxVMQXXvdrgpvQTvOvSh63u4tCLuWidYjmdiwl1Vr6YKgPeBzDQsSPF3sgiCAbxLdnMzDYeAzDSd4VtJV5L76qaP2b1dd6UETLgCfOMxJS3UHeF0ThA23t51Xt326KAibuE/ai1UlRI3rKvuuzUF1rNr58Wn7B8Dk/aC2jIFfrR6qvEh8VQS50dUh1hkWgiL8C9nB2cgZZOBWAAAAAElFTkSuQmCC',
		imageLock: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAA3dJREFUeF7tmz1rFEEYgJ+zOi20uiAGLGMTxCKpZRN/gJDKD8RUJjZa2QgWgo2x0ObQ6oIgVgE7q0uw1kL0qpSCV2gR7gqxi827cL7czuzOzm5mPx44uHvnZu/2Yeadr7vO0dGElmRO6UDL/7SCLLSCLLSCLLSCLGQVFAED4DswAY4r8pjIdx7IPaSmk3KYXwL6wLouqChD4D5wqAs0aQRFwAfgrC6oOFPgOnCgC2axCVoCPtdQTswUWDW1JFsO6tdYDnJvfR2cxSQoqlHOMbFuStwmQXd0oMYk3qtJ0IoO1JjEezUl6UnG/DMG3gF/gA1gWZWPgD3gDHALuKDKT5IpcE4HsQg61gEDY+AK8Fted4GnwD15/QZ4AvyV1z3ga2CSOjqAR0EPgVc6aOEB8FIHT5C5gkw5KAu/dCAFLnVKx5egBR1IgUud0vEl6JsOpMClTun4ELRrW88kcCB1gyaPoBGwBmzqggxsyjVGuiAUXEexkSzy4mE7L11ZFOu5U5l4HcX2PMpBrrWngyHgKqgxuArakG7hi65cMzhcBS1LzkjcJshAFED+ScRVEHJD+7IR7spArhGkHHKMYpo1h7lQJHJCwesoprmsAylwqVM6vgS5LDxd6pSOL0EuC0+XOqXjS9Aj2QSL6QLPZVdyIs9npwU9qRM8vpI0Fd9yJSlJ+xRUdeYK8tXFaksryELIgoYyAV0ATgOX5HBgrN9YJKHmoJvAex0UelLm+1h8bg4KUZBJToxpgy0eLT8BP4EfEr8ILAJXE0bZSgjazbCFq3+aMwSeZVgTRsDjmZYYvCCXbdwbwGtgK0WrSyK+RqFHz3mx/pDJQG/myNuVpaTPDmUU20r6ginIKwfTZxctaCy5YagLZtjN0T0KpyhBUxmNFoFr8liYc1A4ArZVLCiKyEG2fDIA7qZ4XxAU0YJs+WRbWo7tfUHguwXtpNzn8THylIJPQUPJNbXCVxcby4SrdvgQNJVpeyW6TFZ8CKpEsnUlr6CdkCd5Psgr6KMO1I28gs7rQN3IK+iFp194BItpHjTJ+FeEIpi7iVUmphYUb1U2GpOgLzrQREyC3upAEzEJOrBsdDUCkyDkr9OlHtSFhk3QIXBb1luNxCYI6WqrTe1upnnQPCL5A+yKnFQWPU868XlQVkGNI00XazStIAutIAutIAutIAv/AJYW/G8lEjjwAAAAAElFTkSuQmCC',
		imageWarning: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAA7hJREFUeF7tmz1s00AUgL8ysIWfqWXKhrqULgjBwFAFMUNRO8CEusEERYDEXMTAz0QRQxkZqCg7IuoIQsoADGTtRJiaqFuXsjxL5tW+s88X5+z6kyIlzzk7/nL37vycTO3ujmhI55gONPxPI8hCI8hCI8hCI8hCXkEdYB34DQyBg4o8hvKZ1+UcMjOVcZpvAxt5dx4wXWAF2NEbNFl6UAf4USM55DknWw9qy45O6g01YQTMm3qSrQdt1FgOcm4bOhjHJKiTpQvWAON5mgTd0IEak3quJkELOlBjUs/VlKSHOfPPAHgnzxeBWbW9D2wBp4HrwIzaPklGwCkdxCLoQAcMDICLsdmgBTwG7srr18AzYE9et4FvgUma0gE8CroPvNJBC/eAlzo4QRIFmXJQHv7qQAZc2pSOL0HTOpABlzal40vQTx3IgEub0vEhaFMu/vLSlbZBU0RQD7gCLOsNOViWffT0hlBwncX6wIXYtF2UFvA9Ye1UJl5nsS2PcpB9belgCLgKOjK4ClqUYeGLluwzOFwFzQLbpjJBDjqyr0nmn1Rck3SczQIz2QdgSQcnhNckHWfJsSd1ApKTig9BAOd0IAMubUrHlyCXC0+XNqXjS5DLhadLm9LxJeihFMEiWsCaVCWH8jy+LGhLm+DxMYtFDIBPwG4FS66kzWI+BVWdREG+hlhtqWsPGgGfga+x2XIauARcTblbk9iDQha0CbyVMsieJPZFSe5p+WsfeK7uoGiiOy4PgOOxeGUE7QO3gfd6g9CSyUCv3gfSO36peBpz0ssi2ZURdMsgJ0IX2PR9uazE788lCgotSb/JIAcZPsuSawBWHeQgbVZ1ME5IPciljHsTuFagmhDxRWrjhwhF0Ai4nCN/xGnllJrEXNqxQxlid9I+YAaKysF07HELGsj9r57MTklkzTsTYVyCRjIbnZGxfR44m3CjsA88UrGgGEcOsuWTqMxqe18QjKMH2fLJigw52/uCwHcPego80cEEfMw8peBTUDdtLVFlfA2xvhTBaocPQSNZyVZiyOTFh6BKJFtXigoKepHnAx+Cak1RQXM6UDeKCnqRUNmrFSZBqQukGDNSSzkY02NNH7BsTIL+6EDJDKT4PlFMgrZ1oGRWQ1hbmQR91IES6YWyfDAJ6jr+QNwHwdSITIKQ0kSWZO2TSX4xh7AJ2pG/K5YpKfpTXhDYBCHf5nyJ32pQ13WmelASHelRC1JvTvoRQFFOhDB7ReQVdOTIMsSONI0gC40gC40gC40gC/8A/nsj10RJRWkAAAAASUVORK5CYII=',
		lock: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAbdJREFUeF7t2KFOw1AchfFvGJBoQOwJIEGBQiLhDZBLsCgwZGYoJPi9AUgkChzZ3oHagQIUmLul+6fbSUiz5N6cX7KkPd0qvjQV60wmn9hia3GweQ4klBqoCwyAEfCVPqO0deOXl+kU+A46B26BjXgh+QYugPt4oUlpT9AAuFsSh3TtLn1XKukJOgEe4iicAo9xrCsp0AjYDVsFPKXjY2ArXB8De2GbU0qgA+AlbGPgCPhI55vAc0PEQ+A1bDOlvIP24wD0anFIx73a+VTTb2dKCbQTB+AtDgu2pt/OlBKoyU8cFmxL5foOWgeugbOGF+9/VcAQ6NdD5hpoAFzGsSU3wNX0JNdA7y0+OVEFbE9Pcg30G4eWdaYHJb+kW+FAggMJDiQ4kOBAggMJDiQ4kOBAggMJuQaq4tCiuXvnGmgYhxbN3TvXQP30v02bT1KV7tmvj7n+3bEyuT5BK+NAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kOBAggMJDiQ4kPAHJktIg+QbNVUAAAAASUVORK5CYII=',
		lockBottom: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAbBJREFUeF7t2yFOw2AchvFnKBQJAgN+GLgEgoQjAHcYCuQEshg4xNgdEFgOsBnw1CCWoXBgvjbtP93ehNT0y/tLSNq3W8WTpiEkjFarNbbZThyszYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSHAgwYEEBxIcSMg10BgogAWwTj+LtI3jh7cZZfjfPjfAYxwbvoEp8BQvdMntCSpEHIC99JkiXuiS0xN0CTzHUbgC5nFsyinQAjgJWwm8pONz4DBcXwKnYWvJJdAYeA/bEjgDvtL5AfDaEfEY+AhbLZd30EUcgEkjDul40jivdH23lkug/TgAb3HYsHV9t5ZLoC4/cdiwbTXUd9AucA9cd7x4/6sEZul3pDrkUAMVwG0ce/IA3FUnQw302eOTE5XAUXUy1EC/cejZqDrI+SXdCwcSHEhwIMGBBAcSHEhwIMGBBAcSHEgYaqAyDj1q3XuogWZx6FHr3kMNNE1/t+nzSSrTPafN8Q9DSkXRLF5wnwAAAABJRU5ErkJggg==',
		stageLock: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAABzdJREFUeF7tm12IVGUYx392Y7ESGxE4ixeJjVjUheCK0IWORCREtF6ogQkmSFoIfYAKelFGu0IUhOEmpKBSrhca3QRBud6JCkKBRot40dB4t1O5xFzVzf/AzLPv856POTPrhD8YmPO8cz7e/3ne532e95xZNDv7Jw/wecgaHtDJA4FSWLQAQ6wCrAPWAsuBFcBSYInah4EmcA+4C9wG7gBXgStAwxyvp/RLoBqwBVgPPG0bc3ILuAycBy7ZxrLppUAVYB+wHVhmG0uiDhwDTvfKs3ohUBU4ArwKLLaNPaIFnAI+LFuoMoP0EDAO/AJs7aM46FxvKlaN61pKoSwPGgM+7+FQyktdw/uibchLtwINAZ/o7uUhCbTXdNfrwB9qm9NxRyT4cmAUWKNPHiaB93XMQnQjUAX4LsdFTwNngO+7iBMVYBPwOrDBNjpcB14pes6iAlWBnzIMqSR4fgrM2MYuqQLvAjszxLs6sLHINRQRaBT4QQldjCngnaJ3LgcV4DNNDDGawIsa1pnJK1BVGW1MnDqwox9JnKGmfCjm1U1l8Jk9Kc80X9GwiokzBaxaAHHQOVfpGjyG1YeKbfDI6kFDCrKxgHwAOGqNEUYVF1YH6rF7wN/Az8ANeW0e0fcDE9bYxnUF+dTZLatAxyNTeQvYC5y0DQGSwLotxRND1IGzOk+WIfIG8JU1tjEJ7LFGSxaBxoAL1tjGrgziJOVHWiDNyhRwOINQaSJtTksm0wQaAn6NBL4sw2o/8EGGqTgvLc1eH6UMldhwqytuufunBelDEXGmUsSpaEqd6IE46JgHFBtjQfdoJHAvUx9dYh5UVeEZ6twtBVlP+ayJpKXlnC+NtBwnNhJawHPecI150JHIxb4VEWdUs07oYtpp6s7uAlZqBnsYWKTva9U2pU7EGFbyWrUNYk65WYjFmjiCeB5UUREZEmhKs1CISgZxkkWuYxGRLUPA2xpSsdkvraQ450wULRXF87J+z4P2OeK0VD6EGFLxGhNnUkHxaA5x0G+P6thePEHtX1tjG4cdb1ysPs/DE2i7NYhTIZXFoUgi2dJw2ZNTGMucvHeX01F0DePWKGbUhxDBPoeGWE0BNsRKx31jAb0FvJaWbxRgDPgmck4v8FaB36xRbLQZe8iDtliDmHZOSEpA39sDcdAx91qjWKxrCjGjvoSY1/eQQC9bgzhjDaLqBD4Uc9Ky7JpKmZvArD43ZavZHxtORmLS1sis5vVlXt/tEIu534gTf8Y1u1iawDPOPuhcJzKsDE4DuyPeW5GgodnNq7cqbUu8lo5+Wg961mwnXI901CtiJyL71JQOpImDfnM14k2NSCkxzyNEQ8luiHXtG1agtWY74bo1iFHnzrW0eBWiquI3tJ/HsPbxhsxpZ1ZbpmsMcdkaRIcGVqDlZjvBS+E3WoP4NuI9J3KKkzCsfUM0dM4Q3jV6ferQwAq0wmwn3LEGsdoaxA1rELWMw8pjQ2Soeef0rtHrU4cGVqClZjuhbg3CE9TLo+ZNowXwjuGd07tGr08dGliBkiVPixfx8wq63hoK4B3DO+dT1iC8PnVoYAV6xGwneOXBE9YgvPgTW7fJineMv6yhIB0aWIHy8o81iNJeHsiBdxO7wgqUt8P3rEE8ag3C86w8xI7hDbM8dGhgBcrb4bvWIFZZg/ByjzzEjrEvkA9Nmu2EEWsQHRpYgfJ2+LY1CC/hPG8NBYgd46LymM3Kf0aAg/ZHKXRoYAXyOuwlkF7u8ZI1iEuRSjoL03Y5IkBDQl1KGY4zTonSoYEVyEuevHTdyz02RGab3Spk89LUvmVyUN7Wfj0dN90KdNVsJ3grhdcind1kDWImcFFpNLWPV9F3w0WtOkzoc6y90Qp0xWwnrIl4hBcEvRwJuf/ajMNtWr9NG1rd0JA3HbTpghWoEZkqPY/wFsQ8b0yYUV21USLfkqc09X1SbbUeeU4m7IIZkRcVpiOFon2cEns0NFCEBCqyaJ88t3pSccnzqoEjJBDA787zLW8J83+LjUEJZ61B7IwE67xU9XrKcXndLPCvPsnC/Tn9ZsHwPCi2qN1tfBlTSZBn4Sz1PZ5e4XlQI+Vxipc4xhiVV1zIKQ7AY9bQLzyBiDzHBnjPGiIk/+G4WvCvUPXIzeo5MYFiz7GftwaHitKD0HOzrOywyVs/iQmE/ucQShy9qr+dCvBjpEzJQpbitKekCTTnvBbysTUYkldhigypdrxHxH3Dm8UsY22Z8pcZ7qqXjefFS0z7RlaB8hDLxPOyZCHjDxmGWBG+sIYuWFBx6IFAYyXEnfuKsgUKBfSBpkyBKgUy5PueMgUKVf8DT5kC3YyUJgNLmQLNRd7RGVjKFAi9ZB4qTQaWsgVq6AlElv9XDARlC4RE2gY8rip+oD2qF6VGiJr+rvRCjuq+pX//LCj9Eqidil61XamnIKv0Fph9u22ywIsHpbMQAg0UvYhB/yseCJTCf3kdyZ9PT7cnAAAAAElFTkSuQmCC',
		textController: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAxBJREFUeF7tmrGKFEEQhv+VzRTz20SDE0RDDzPBpzAw0NRcg8UHEIU1v9jgQh9EzlAxMNBkN5JDwcgDTWph/enq7pnpqukZ+oMJ7r+hYL/t7ZrunsXFxU80dK5w0PifJihBE5SgCUrQBCXwFrQEsAGwlWsjWbUsnNv8BsBzyt4CeEFZNXgL2gI4omwHYEVZNXj+xI4DcgDgOgc14SnoDgfCFw5qwlPQXQ6ETxzUhKeg2xwIbQQJbQQl0EbQZw5qwkvQMYCrHAL4DeAbhzXhJSjWwS45rAkvQZOcf+AoSJt/qu5gcBTURlACbQRV3cHgJGiyHQxOgibbweAkaLLzDzoIOtwJ/NvxesXFhCeBezd809jkbpiFdgKtuAXgK4djkTuCHnNgyAMOxiRXkCcPORiTXEFnHBhyjYMxyRW0ltOHHf+jMDsAbzgck1xBl3I0swKw6HC940LCy8C9C6n/gW8ek1xBfZn0MxAcBE12DbbHUlBsDTb0OcftuNpSUGwN1pcVgHMAfw6evrcA7vONpbAUZDH/PAVwj7IjAI8oK4alIG3+GTKCtJo/OCiFpSCLEWRRM4qlIO3bPuegA1pNs65oJSjWwbYcZhKrObQrqlgJsuhgFjWTWAmymCssaiaJbZgtAbyWvaDQi09TZSe7E+ucPfGYIM9dxDHIejcyJij0PuGcyHo30moOmg0xQZ67iGOQ9fligrx2Eb3Zyeda8z9CxAR57SLmXO+5mNCn5ko+V7KDISGoLxbPKzc4EIbUzMJCUOn10tKgZjalBWnrJQx4k+OmUtN0DbantCBtvfQx9zcfQKtpugbbU1qQNv9856ADWk3z+QcGgrS5wmIPaFYjaMi3bVEzm5KCrLqNRc1sSgrSug0GdDCtK7p0MBQWpHWbyXYwFBakzRWT7WAoLOiEA2GyHQyFBVmsl2Y1grRve0i3sajZiZKCQgx9m/4XB7Kf49LBUFjQKQeS9e1gUHb9QpkZsU37ruyPiZ7J36e5RysRDo+e0OW4phQlBc2Skj+xWdIEJWiCEjRBCZqgBP8A62WrBVtAdGgAAAAASUVORK5CYII=',
		textLock: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAvhJREFUeF7tmr1uE1EQhY9pIoFEjUvkhr8GHoSCniegRFAQuUJQODUvAE/Ai1ARoIAOKZYoIpBYkQqaWSmM9u6dtefMvdfaT7rNcTSRP2d3MrNenJ//xEyaKzqY+Z9ZUIZZUIZZUIZZUIZoQUcANgDO5Gwkq5ZFcJvfAHimshMAz1VWDdGCzgDcUNkWwFJl1RB5ia0G5ADAdR3URKSguzoQPuugJiIF3dOB8EkHNREp6JYOhC86qIlIQXd0IHzUQU1ECrqtA+FUBzURJWgF4KoOAXQAvumwJqIENdnBECioyQ6GQEFNdjAECmqygyFQUJMdDEGCmu1gCBLUbAdDkKBmOxgmCLq8Cfw78bzSxYTHAz/bn9/y+4pjXZgNbQLZdACu6TAaq6ChTWAECx1EY73ESlF8oW8V9E4HAXQALnQYjVXQWp4+bPULJDoAT3VYAus9aFfeSrfSHAN4rcMasf4F7UqzM1gPW1CzM1gPU1DTM1gPU1DTM1gPUxBrBnsoZxXxfxJTEGOL+ALAezlfAfyRGz5NFFMQo4M90oFcyvd16AVTEKODpWr+0IEXLEGMDsaomYUliNHBGDWzsAQxOhijZpaxWewIwEuZpUrsglhsZTuxtmwLxgSV2CJGYvpu5JigUlvEKEzfjWTdgw6GMUEltoiRmN7fmKDoLWIUW3lfa/3CEGOCLuQmtpSnC9aT+mSOB37WejxrLuV9ZTsYMoJ2hTGDPdCBsE9NEwxBqXlpnxnspg6EfWqa8BaUmpcA4LsOjKRqUmewHm9BqXnp1HrND5CqSZ3BerwFpealDzqYQKomdQbr8RbE2CIyaprxFsToYIyaZrwFMToYo6YZT0GpboNWOxicBaW6TbMdDM6CUt2m2Q4GZ0GMbsOoOQlPQYx5qWgHg7MgxrxUtIPBWdAQ3R4dDAB+6UD2OSEdDM6C3uhAsl07GBJ7oKGMxtjSfir9Y6In8smbH62McPnRE5xqTsJT0EHieYkdJLOgDLOgDLOgDLOgDP8Ay/SxAW4VWRsAAAAASUVORK5CYII=',
		textWarning: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAuRJREFUeF7tmrGqE1EQhv9YWWpnai+IiJW1j+ALCJaCL3AvpLJU4iPcUq5PYycigtZJl9jdTpuzoMPOnjk588+ejeeDhTBZBvKxs5OZ3dXh8AsdnTsy0PmXLihDF5ShC8rQBWWYQ9AWwC4dW/lla0QL2gK4BPAgHZetS1oF/w86ALgnYnsAaxFrhsgr6GJEDgDclYGWiBT0WAYSP2WgJSIFPZGBxHcZaIlIQU9lIPFFBloiUtAjGUh8lYGWiBSkldg3GWiJKEEXSre6BfBDBlsiSpDWwZouLwQK0sqr6Q6GQEGL7GAIFLTIDoZAQVqJNd3BECRosR0MQYIW28EQJEgrr+Y7GAoFDZvA34XHO5ko8VKcdwDwRp40N9aF2bAJZHMEcF8G58QqaJdWpBGsZGBOSkrsv8Qq6KMMkDjKwNxYBV0B+JAW7CyOADYyODfWe9Cp3KRuJdkAeC+DLWK9gk5lsTPYAFvQQxlIND+DDTAFac/BFjGDDTAFLXoGG2AKWvQMNsAUxNgivhiZBz/LkzxhCmJ0sLcjI88zAM9FzA2mIK3EajqYlnMnA16wBGlbxGNFB9NyUrsiS5DWwWre5NBy1pRsFpYgrRRqOhgjZ5bcLLYF8Grkxrhk9mk7cSW/GGPqCvr7fcJzoujdyKkrKHKLOAemdyOnrqBORlDUFnEuTL9vSlDEFnEO9ul3Vd+kkZKs05MG6/FJJklsRs61Hp4511Y5MAg6BcYMxshpgiFI+0PHmMFqcprwFsSYlxg5zXgLYsxLjJxmvAVppVAzLzFymvEWxNgiMnKa8RbE6DaMnGa8BWnlUNNtGDnNeApidBtGziI8BTG6DSNnEZ6CtFKo6TaMnEV4CmJ0G0bOIjwFMboNI2cRnoK0cqjpNrO/HeIp6FYGKp+DgZSzCE9B1zKgxEoY2/rV5ixiaml/ClsAr9Pn65LF1ATDoyeUPK7xwlvQ2eFZYmdJF5ShC8rQBWXogjL8ATCFoXPkBUrHAAAAAElFTkSuQmCC',
		voiceLock: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAA7ZJREFUeF7tmytsFFEUhr+SjAOxEhCrCCSgEBNwJEBJwNQsyCZgQIEEgwCSbVAlIUBFmxQHGAzPBoMpIHmFOhB0HA3pKiqKOUOmJ3PvndnOY+9yv6Rp+u+K9uu9Z8597MTa2m8CZnboILCVIMhBEOQgCHIQBDloU1AHmAfWgVWgD0T6TW0z0dJjvgMsA/tVPgNcU1mrtDGCIuB5jhyAaR20TdOCIuAZcES/IOzWQds0LegBcFKHo0yTgvrAeR2OOk0Jugxc1aEPNCGoB8zq0BfqFtQDHuvQJ+oUFAMLOvSNugTFwBtgp37BN+oQ1AWejoMcahDUAV6NYsM3LFUK6liWEN5SlaAIeGRZQniLTVAk3e8qsOn4+uPbEqIoNkE3pPsdm3oyDDZBI7f10AY2Qf/1yEmxCQoEQW6CIAdBkIMgyEEQ5CAIchAEOQiCHARBDoIgB+MgqJ+z/dLXb8pQ6v222x2bOmiICR1Y6ALfdQgkwB4dyq7nLx0CA2CXDhmDETSlA+GHDoR9OhB+6iDFd0FndCB81YHQ1YGwpoMUnwXFlm3elzoQDutAMAn1VlAHeKhDIZFzuTyO6UD4qIMUHwW5jpcWgQ0dyvQynbos6yDFN0Gx/DGmPzQBbutQMBX0BPigwxSfBKXn/aaRg9xDyiu4EXBJh8ILHWTxSdAtx3n/DPBEh8KUReycDrL41CiuWwQtABcNtScCPhkErQAHdJjFpxFkwiYHOQDNkwNwXwcam6BEBy1zV/2cAGeBCxY5seVuZALc06HGJmhRBy1zXerMknw/aKk5yGPd1CshBd0k9h+2GhTJ8Jxu+JTVVIPKYPqoQ8oSMKnDPGyCypDeoDe1/mXYrqC0kTT1SgPgkGVBuwXbFCvDBnAOeKdfaJgY+GKRg1xmLySHCgUhDdppeXQ2TSQ15b2jHNh6pVyqFIRIOtXwE7AnfY7rsvrCMB+1qloQMnynZK7XRVdGzDe5qG4qxilpr1SaOgQhi7/jNUiKgdeyzTpbQAwyrWy9kpW6BCGSqvx0T09qTNEn5UAaydLTKkudgpCCeFaHQ3JTBxaW5FFeqiDnUbcg5Je8osMh2KuDHNLlx2SZR7mNJgQB3JFasB0+6yDDivwTulWMmixVddJFmS9Ql0yddCx7zWmfk8hm15xtR3C7NC2oyJLEJAhZRpyQ6VOblCxNC0IkvTUsB0wnoq3RVA3KsmFZkozaFksrgpAlyVHpcAcycmZkz2ekaGOKeUVbI8gbgiAHQZCDIMhBEOTgLwBRuMaSuSBMAAAAAElFTkSuQmCC',
		voiceWarning: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAA7ZJREFUeF7tmytsFFEUhr+SjAOxEhCrCCSgEBNwJEBJwNQsyCZgQIEEgwCSbVAlIUBFmxQHGAzPBoMpIHmFOhB0HA3pKiqKOUOmJ3PvndnOY+9yv6Rp+u+K9uu9Z8597MTa2m8CZnboILCVIMhBEOQgCHIQBDloU1AHmAfWgVWgD0T6TW0z0dJjvgMsA/tVPgNcU1mrtDGCIuB5jhyAaR20TdOCIuAZcES/IOzWQds0LegBcFKHo0yTgvrAeR2OOk0Jugxc1aEPNCGoB8zq0BfqFtQDHuvQJ+oUFAMLOvSNugTFwBtgp37BN+oQ1AWejoMcahDUAV6NYsM3LFUK6liWEN5SlaAIeGRZQniLTVAk3e8qsOn4+uPbEqIoNkE3pPsdm3oyDDZBI7f10AY2Qf/1yEmxCQoEQW6CIAdBkIMgyEEQ5CAIchAEOQiCHARBDoIgB+MgqJ+z/dLXb8pQ6v222x2bOmiICR1Y6ALfdQgkwB4dyq7nLx0CA2CXDhmDETSlA+GHDoR9OhB+6iDFd0FndCB81YHQ1YGwpoMUnwXFlm3elzoQDutAMAn1VlAHeKhDIZFzuTyO6UD4qIMUHwW5jpcWgQ0dyvQynbos6yDFN0Gx/DGmPzQBbutQMBX0BPigwxSfBKXn/aaRg9xDyiu4EXBJh8ILHWTxSdAtx3n/DPBEh8KUReycDrL41CiuWwQtABcNtScCPhkErQAHdJjFpxFkwiYHOQDNkwNwXwcam6BEBy1zV/2cAGeBCxY5seVuZALc06HGJmhRBy1zXerMknw/aKk5yGPd1CshBd0k9h+2GhTJ8Jxu+JTVVIPKYPqoQ8oSMKnDPGyCypDeoDe1/mXYrqC0kTT1SgPgkGVBuwXbFCvDBnAOeKdfaJgY+GKRg1xmLySHCgUhDdppeXQ2TSQ15b2jHNh6pVyqFIRIOtXwE7AnfY7rsvrCMB+1qloQMnynZK7XRVdGzDe5qG4qxilpr1SaOgQhi7/jNUiKgdeyzTpbQAwyrWy9kpW6BCGSqvx0T09qTNEn5UAaydLTKkudgpCCeFaHQ3JTBxaW5FFeqiDnUbcg5Je8osMh2KuDHNLlx2SZR7mNJgQB3JFasB0+6yDDivwTulWMmixVddJFmS9Ql0yddCx7zWmfk8hm15xtR3C7NC2oyJLEJAhZRpyQ6VOblCxNC0IkvTUsB0wnoq3RVA3KsmFZkozaFksrgpAlyVHpcAcycmZkz2ekaGOKeUVbI8gbgiAHQZCDIMhBEOTgLwBRuMaSuSBMAAAAAElFTkSuQmCC',
		warning: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAkJJREFUeF7tmDFrFEEYhp/YpLj+rJJCsQrEQn/FSf5BwDJW6QyYJngBBa0FbcSAf0F/hRbaCjZW2SZYWFxnMye7383sm+BpmOF9YOHm3dktHmb2vd2Ni4ufmDI3YmCGWJCgdUEz4F06ZvHkZdho+Bl0ALwO2SPgTchGaVXQFvAN2Az5ArgD/Ah5kVa32KuMHFJ2GsMxWlxB94BPMQzcBz7HMEeLK+htDDJcZg40KOgA2I1hht00V9LSFpsA34FpGnfAWZjzMJy/BfwKcwa0JOgF8Lg3fgB87I1J/4U+9MYvgaPeeIVWttgWcBiy8zDOZYfp2iKtCMrV+s0wzmWb6doiLQiaAXsxLKyMXLY39hrSgqDnMUjcjkEhY+Qe1Qsaq/VlW6mMsdqvWdAEmMewx3YMCtmSebrngJoFnYysCICd9NrRP3bipB7TdM8Btf4PKr2t/y0rb/u1rqBcra+DldqvUVCp1iML4Dg9d7bT70WclGFQ+zVusS8jzdXnOFPfT4BnIcvxFbhLhStorNYj72NQyHL8qf2aBKlaXzdzYFKTIFXrkf0YFLISU+CkpmfQ+RUFLYCnvW21nyRfpf26lgWtg66mLRa/Dv4PzmoSdJS+AHbxxD+gW35trGmLXQs1raBrwYIEFiSwIIEFCSxIYEECCxJYkMCCBBYksCCBBQksSGBBAgsSWJDAggQWJLAggQUJLEhgQQILEliQwIIEFiSwIIEFCSxIYEECCxJYkMCCBBYksCCBBQksSGBBAgsSWJDgN3XIXq1FVd/qAAAAAElFTkSuQmCC',
		warningBottom: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAAYdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuOBtp6qgAAAC2ZVhJZklJKgAIAAAABQAaAQUAAQAAAEoAAAAbAQUAAQAAAFIAAAAoAQMAAQAAAAIAAAAxAQIAEAAAAFoAAABphwQAAQAAAGoAAAAAAAAA8nYBAOgDAADydgEA6AMAAFBhaW50Lk5FVCA1LjEuOAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlAAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADMbhZ8SlPoHAAAAllJREFUeF7tm7FqVEEUhr9YpFuWiKjd2hgiQZv4BusTBNL4FglBJClSKYagNsY3sNUn8CHEQrGzcrFZl3Rb2czK5ORO/l10DTP8H9zi/PfuFh935swe2JXxeIIpcy0G5jwWJLAggQUJLEhgQQILEliQwIIEFiSwIIEFCSxIYEECCxJYkMCCBBYksCCBBQksSGBBAgsSWJDAggQWJLAggQUJLEhgQQILEliQwIIEFiSwIIEFCSxIYEECCxJYkMCCBK0LGgJv0zWMN+dhpeG/IuwCr0K2B7wO2aW0KmgAfAL6IZ8C68D3kBdpdYmddMgBWE335qZFQUNgJ4YZO4vsRy0KOo5BB/M8Aw0KegxsxbCDrfSspKVNugd8A26negR8AMapXktSZnvTKG3YZ6nupCVBz4CDrH4EfMxqkqB3Wf0cOMzqC7SyxAbAfsh+hhrgc6j302eLtCLoJLXwnJuhBrgfatn2WxBUausPYgDcioFq+y0IKrXsGzEoZABvYjCjdkGXtfW1GAB3Y5DYSL/dLlCzoB7wMoYZ6zEArscg4yh95zlqFvQ0O/N0sZk25fzajA9l9LuWa63noEE6FMbO9bdMgYf5caDWN6irrf8LVuO8qEZBpbYemaYB2Z107aVMMczbfo1L7EvqOoqu6WHXlLGLr8A9KnyDdueUA/A+BoWsiz9tvyZBPeBJDJfIEdCrSZBq65HtGBSyEn3guKY96MeCgqZJ6mxZbQMvFux+k5oE/SoM4pfJpKYldhqD/8BpTYIO0wRwFG8sgdFs2ljTErsSanqDrgQLEvwGs0RbZcLPQ2gAAAAASUVORK5CYII=',
	}

	// Channel icon pictures: a plain symbol with a spot where the lock, warning or controller goes.
	var KIND = {
		Lock: { fallback: '#f0b232', token: 'STATUS_WARNING' },
		Warning: { fallback: '#f23f43', token: 'STATUS_DANGER' },
		Controller: { fallback: '#23a55a', token: 'STATUS_POSITIVE' },
	}
	var GLYPHS = {
		AnnouncementsLock: { kind: 'Lock', base: 'announcementLock' },
		AnnouncementsWarning: { kind: 'Warning', base: 'announcementWarning' },
		TextLock: { kind: 'Lock', base: 'textLock' },
		TextWarning: { kind: 'Warning', base: 'textWarning' },
		TextController: { kind: 'Controller', base: 'textController' },
		VoiceLock: { kind: 'Lock', base: 'voiceLock' },
		VoiceWarning: { kind: 'Warning', base: 'voiceWarning' },
		ForumLock: { kind: 'Lock', base: 'forumLock' },
		ForumWarning: { kind: 'Warning', base: 'forumWarning' },
		StageLock: { kind: 'Lock', bottom: true, base: 'stageLock' },
		ImageLock: { kind: 'Lock', bottom: true, base: 'imageLock' },
		ImageWarning: { kind: 'Warning', bottom: true, base: 'imageWarning' },
	}

	var storage

	function finders() { return valenced.modules.finders }
	function setting(key) {
		var s = storage && storage.cache
		return s && s[key] !== undefined ? s[key] : defaults[key]
	}
	function h(type, props) {
		var children = Array.prototype.slice.call(arguments, 2)
		var rt = valenced.react.ReactJSXRuntime
		var p = Object.assign({}, props)
		var key = p.key
		delete p.key
		if (children.length === 1) p.children = children[0]
		else if (children.length > 1) p.children = children
		return (children.length > 1 ? rt.jsxs : rt.jsx)(type, p, key)
	}

	/** Turns one of Discord's theme colors into a plain color for the current theme, when it can. */
	function resolveColor(token) {
		try {
			var Tokens = valenced.discord.common.tokens.Tokens
			var color = Tokens.default.colors[token]
			if (!color) return undefined
			var theme = valenced.discord.flux.Stores.ThemeStore && valenced.discord.flux.Stores.ThemeStore.theme
			var internal = Tokens.default.internal
			if (internal && typeof internal.resolveSemanticColor === 'function' && theme) {
				var resolved = internal.resolveSemanticColor(theme, color)
				if (resolved) return resolved
			}
			return color
		} catch (e) {
			return undefined
		}
	}

	function assetId(source) {
		if (Array.isArray(source)) source = source[0]
		if (typeof source === 'number') return source
		if (source && typeof source === 'object') {
			if (typeof source.original === 'number') return source.original
			if (typeof source.default === 'number') return source.default
		}
	}

	function assetName(source) {
		var id = assetId(source)
		if (id === undefined) return undefined
		var asset = valenced.assets.AssetsRegistry.getAssetByID(id)
		return asset && asset.name
	}

	/**
	 * Works out which glyph an icon is from its name, so it still works when Discord spells the name
	 * differently (TextLockIcon, ic_channel_text_locked, channel-text-lock...).
	 */
	function glyphFor(name) {
		var n = String(name).toLowerCase().replace(/[^a-z]/g, '').replace(/icon$/, '')
		var kind = /lock/.test(n) ? 'Lock' : /warning|nsfw/.test(n) ? 'Warning' : /controller|gamepad|game/.test(n) ? 'Controller' : null
		if (!kind) return undefined
		var type = /announcement|news/.test(n)
			? 'Announcements'
			: /forum/.test(n)
			? 'Forum'
			: /stage/.test(n)
			? 'Stage'
			: /image|media|photo/.test(n)
			? 'Image'
			: /voice|audio|speaker/.test(n)
			? 'Voice'
			: /text|channel/.test(n)
			? 'Text'
			: null
		return type ? GLYPHS[type + kind] : undefined
	}

	// ---- Icon pack support -------------------------------------------------------------------------
	// Icon packs swap the pictures behind Discord's own icon names, so anything drawn through
	// Discord's assets follows the pack. These helpers find those assets by name.

	/** Lowercase letters only, without the `ic_` start or the `Icon` end, so spellings compare equal. */
	function norm(name) {
		return String(name).toLowerCase().replace(/^ic[_-]/, '').replace(/[^a-z]/g, '').replace(/icon$/, '')
	}

	var registryIndex = {}
	var scanned = 0
	function scanRegistry() {
		var registry = valenced.assets.AssetsRegistry
		for (var id = scanned + 1; id < 100000; id++) {
			var asset = registry.getAssetByID(id)
			if (!asset) break
			scanned = id
			var name = asset.name
			if (typeof name === 'string' && (/icon$/i.test(name) || /^ic[_-]/i.test(name))) {
				var key = norm(name)
				if (key && registryIndex[key] === undefined) registryIndex[key] = id
			}
		}
	}

	/** The first asset id whose name matches one of the keys. Looks again when Discord has loaded more assets. */
	function findAsset(keys) {
		for (var pass = 0; pass < 2; pass++) {
			for (var i = 0; i < keys.length; i++) if (registryIndex[keys[i]] !== undefined) return registryIndex[keys[i]]
			if (pass === 0) {
				try { scanRegistry() } catch (e) { return undefined }
			}
		}
	}

	// The plain channel icons by type. 'text' alone is left out of Text on purpose: it could be the "Aa" icon.
	var PLAIN = {
		Text: ['hashtag', 'pound', 'channeltext', 'textchannel'],
		Announcements: ['announcements', 'announcement', 'channelannouncements', 'megaphone', 'news'],
		Voice: ['voicenormal', 'voice', 'channelvoice', 'speaker'],
		Forum: ['forum', 'channelforum'],
		Stage: ['stage', 'stagechannel', 'channelstage'],
		Image: ['image', 'mediachannel', 'channelmedia', 'media', 'photo'],
	}
	// The small symbols by kind. They come from the pack too, because every pack has a lock.
	var BADGE = {
		Lock: ['lock', 'padlock'],
		Warning: ['warning', 'circleexclamationpoint', 'exclamationpoint', 'circleexclamation', 'triangleexclamation', 'alert'],
		Controller: ['gamecontroller', 'controller', 'gamepad'],
	}

	function typeOf(n) {
		return /announcement|news|megaphone/.test(n)
			? 'Announcements'
			: /forum/.test(n)
			? 'Forum'
			: /stage/.test(n)
			? 'Stage'
			: /image|media|photo/.test(n)
			? 'Image'
			: /voice|audio|speaker/.test(n)
			? 'Voice'
			: /hashtag|pound|text/.test(n)
			? 'Text'
			: null
	}

	// The plain icon each channel type is drawn with, learned from the channels Discord draws.
	var learned = {}
	function learnPlain(name, props) {
		var type = typeOf(norm(name))
		if (type && !learned[type]) learned[type] = { source: props.source, component: props.IconComponent }
	}

	/**
	 * The plain icon for a channel type, as the props that draw it. Discord's channel icon draws from an
	 * IconComponent when it is given one, so the component has to be swapped with the picture.
	 */
	function plainOf(type, props) {
		var seen = learned[type]
		if (seen) return props.IconComponent !== undefined && seen.component === undefined ? undefined : seen
		if (props.IconComponent !== undefined) return undefined
		var id = findAsset(PLAIN[type] || [])
		return id === undefined ? undefined : { source: id }
	}

	/** How big the icon is drawn, for sizing the symbol. */
	function sizeOf(props, ret) {
		var RN = valenced.react.ReactNative
		try {
			var style = RN.StyleSheet.flatten([props.style, ret && ret.props && ret.props.style])
			if (style && typeof style.width === 'number') return style.width
			if (ret && ret.props && typeof ret.props.size === 'number') return ret.props.size
			if (typeof props.size === 'number') return props.size
		} catch (e) {}
		return 18
	}

	/** How far the icon is pushed from the left edge of its box by its own margin. */
	function leftMargin(props, ret) {
		var RN = valenced.react.ReactNative
		try {
			var style = RN.StyleSheet.flatten([props.style, ret && ret.props && ret.props.style]) || {}
			var m = style.marginLeft !== undefined ? style.marginLeft : style.marginHorizontal
			return typeof m === 'number' ? m : 0
		} catch (e) {
			return 0
		}
	}

	/** The icon with its colored symbol, built from the pack's own pictures. */
	function decoratePack(props, ret, glyph, badge) {
		var RN = valenced.react.ReactNative
		var kind = KIND[glyph.kind]
		var tint = setting('colorIconsFallback') ? kind.fallback : resolveColor(kind.token) || kind.fallback
		var size = sizeOf(props, ret)
		var side = Math.max(8, Math.round(size * 0.6))
		// The symbol sits in the icon's own top right (or bottom right) corner. It is placed from the left edge of the icon,
		// so the icon's right margin does not move it into the channel name.
		var left = leftMargin(props, ret) + size - side + 2
		var place = glyph.bottom || glyph.kind === 'Controller' ? { bottom: -2, left: left } : { top: -2, left: left }
		if (badge === undefined) {
			// The pack has no symbol this plugin can find, so the built-in mark is drawn over the pack's icon. That picture is
			// the size of the whole icon with the mark already in its corner, so it covers the icon from its top left.
			var mark = glyph.kind === 'Controller' ? IMAGES.controller : IMAGES[glyph.kind === 'Lock' ? (glyph.bottom ? 'lockBottom' : 'lock') : glyph.bottom ? 'warningBottom' : 'warning']
			return h(
				RN.View,
				{},
				ret,
				h(
					RN.View,
					{ pointerEvents: 'none', style: { position: 'absolute', left: leftMargin(props, ret), top: 0 } },
					h(RN.Image, { style: { width: size, height: size, tintColor: tint }, source: { uri: mark } }),
				),
			)
		}
		return h(
			RN.View,
			{},
			ret,
			h(
				RN.View,
				{ pointerEvents: 'none', style: Object.assign({ position: 'absolute' }, place) },
				h(RN.Image, { style: { width: side, height: side, tintColor: tint }, source: badge }),
			),
		)
	}

	/** The built-in pictures, used when the pack's icons can't be found. */
	function decorateClassic(props, ret, glyph) {
		var RN = valenced.react.ReactNative
		var kind = KIND[glyph.kind]
		var overlay = glyph.kind === 'Controller' ? IMAGES.controller : IMAGES[glyph.kind === 'Lock' ? (glyph.bottom ? 'lockBottom' : 'lock') : glyph.bottom ? 'warningBottom' : 'warning']
		var iconColor = typeof ret.props.color === 'string' ? ret.props.color.replace(/-/g, '_').toUpperCase() : ''
		var styled = RN.StyleSheet.flatten([props.style, ret.props.style, { width: 18, height: 18 }, iconColor && resolveColor(iconColor) ? { tintColor: resolveColor(iconColor) } : null])
		var tint = setting('colorIconsFallback') ? kind.fallback : resolveColor(kind.token) || kind.fallback
		return h(
			RN.View,
			{},
			h(RN.Image, { style: styled, source: { uri: IMAGES[glyph.base] } }),
			h(
				RN.View,
				// Over the picture it belongs to, from its top left corner. (Anchoring it to the bottom right of the box would
				// include the icon's margin and push the symbol right, into the channel name.)
				{ style: { position: 'absolute', left: 0, top: 0 } },
				h(RN.Image, { style: Object.assign({}, styled, { tintColor: tint }), source: { uri: overlay } }),
			),
		)
	}

	/** Draws one channel icon: the pack's plain icon with a colored symbol, or the built-in picture. */
	function drawIcon(args, original, self) {
		var props = args[0] || {}
		var name = setting('colorIcons') ? assetName(props.source) : undefined
		if (!name) {
			// An icon drawn from a component has no asset name. Its component's name still says which channel type it is,
			// so the pack's plain icon can be learned from it too.
			try {
				var component = setting('colorIcons') && props.IconComponent
				var componentName = component && (component.displayName || component.name)
				if (componentName) learnPlain(componentName, props)
			} catch (e) {}
			return Reflect.apply(original, self, args)
		}
		var glyph = glyphFor(name)
		if (!glyph) {
			try { learnPlain(name, props) } catch (e) {}
			return Reflect.apply(original, self, args)
		}
		var type = glyph.base.replace(/(Lock|Warning|Controller)$/, '')
		type = type.charAt(0).toUpperCase() + type.slice(1)
		if (type === 'Announcement') type = 'Announcements'
		var plain, badge
		if (setting('followPack')) {
			try {
				plain = plainOf(type, props)
				badge = findAsset(BADGE[glyph.kind])
			} catch (e) {}
		}
		if (plain !== undefined) {
			var next = Object.assign({}, props, { source: plain.source })
			if (plain.component !== undefined) next.IconComponent = plain.component
			var ret = Reflect.apply(original, self, [next].concat(Array.prototype.slice.call(args, 1)))
			try { return ret && ret.props ? decoratePack(props, ret, glyph, badge) : ret } catch (e) { return ret }
		}
		var plainRet = Reflect.apply(original, self, args)
		try { return plainRet && plainRet.props ? decorateClassic(props, plainRet, glyph) : plainRet } catch (e) { return plainRet }
	}

	function NsfwBadge() {
		var RN = valenced.react.ReactNative
		return h(
			RN.View,
			{ style: { backgroundColor: '#f23f43', borderRadius: 4, paddingHorizontal: 4, paddingVertical: 1, marginRight: 6, alignSelf: 'center' } },
			h(RN.Text, { style: { color: '#ffffff', fontSize: 10, fontWeight: '700' } }, 'NSFW'),
		)
	}

	function SettingsComponent(props) {
		var Design = valenced.discord.design.Design
		var RN = valenced.react.ReactNative
		var json = props.api.jsonStorage
		storage = json
		var settings = Object.assign({}, defaults, json.use())
		function toggle(key, label, subLabel) {
			return h(Design.TableSwitchRow, {
				key: key,
				label: label,
				subLabel: subLabel,
				value: !!settings[key],
				onValueChange: function (v) { var patch = {}; patch[key] = v; json.set(patch) },
			})
		}
		return h(
			RN.ScrollView,
			{ style: { flex: 1 }, contentContainerStyle: { paddingBottom: 38 } },
			h(
				Design.Stack,
				{ style: { paddingVertical: 24, paddingHorizontal: 12 }, spacing: 24 },
				h(
					Design.TableRowGroup,
					{ title: 'Channels' },
					toggle('nsfwTag', 'NSFW tag', 'Adds a red NSFW tag next to channel names'),
					toggle('colorIcons', 'Colored icon symbols', 'Turns locked channel symbols yellow, NSFW channel symbols red'),
					toggle('colorIconsFallback', 'Fallback colors for icon symbols', 'Uses yellow, red and green regardless of theme'),
					toggle('followPack', 'Follow icon packs', 'Draws the channel icon and its symbol from the icon pack in use. Falls back to built-in pictures when the pack has no match'),
				),
				h(
					Design.TableRowGroup,
					{ title: 'About' },
					h(Design.TableRow, { key: 'credit', label: 'Credit', subLabel: 'Based on Colorful Channels from NexxUtils by nexpid. Open the chat list again to see changes, or reload Discord after changing icon pack.' }),
				),
			),
		)
	}

	var registerCleanup = function (fn) { return fn }
	function patchIcons(module) {
		var holder = module && typeof module.BaseChannelIcon === 'function' ? module : module && module.default && typeof module.default.BaseChannelIcon === 'function' ? module.default : null
		if (!holder) return
		try {
			registerCleanup(
				valenced.patcher.instead(holder, 'BaseChannelIcon', function (args, original) {
					return drawIcon(args, original, this)
				}),
			)
		} catch (e) {}
	}

	Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
	exports.default = plugin({
		jsonStorage: { load: true, default: defaults },
		SettingsComponent: SettingsComponent,
		start: function (api) {
			var cleanup = api.cleanup
			registerCleanup = cleanup
			storage = api.jsonStorage
			var f = finders()

			// The red NSFW tag next to the channel name.
			cleanup(
				f.getModules(
					f.filters.withName('ChannelInfo'),
					function (module) {
						if (!module || typeof module.default !== 'function') return
						cleanup(
							valenced.patcher.instead(module, 'default', function (args, original) {
								var ret = Reflect.apply(original, this, args)
								try {
									var channel = args[0] && args[0].channel
									if (!setting('nsfwTag') || !channel || !(channel.nsfw_ || channel.nsfw)) return ret
									return h(valenced.react.React.Fragment, {}, h(NsfwBadge, {}), ret)
								} catch (e) {
									return ret
								}
							}),
						)
					},
					{ returnNamespace: true },
				),
			)

			// The channel icons. This part of Discord loads when the channel list first draws, which on a
			// fresh start is after this plugin starts, so wait for it instead of looking once.
			cleanup(
				f.getModules(
					f.filters.withProps('BaseChannelIcon'),
					patchIcons,
					{ returnNamespace: true },
				),
			)
		},
	})
	return exports
})({})
