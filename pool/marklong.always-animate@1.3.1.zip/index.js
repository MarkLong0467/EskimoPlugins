(function (exports) {
	/*
	 * Always Animate for Valenced
	 *
	 * Animates everything that can be animated. The idea comes from AlwaysAnimate for Vencord. The code is written from
	 * scratch for Valenced, using the decompiled Discord app (Wumpus-Central/discord-mobile-datamining, version 354).
	 *
	 * What the decompiled app shows, and what this plugin does about it:
	 *
	 * 1. Pictures. `discord_app/utils/AvatarUtils.tsx` builds every avatar, banner, server icon and decoration address.
	 *    Each function is told whether the picture "canAnimate". When it is false Discord asks for a still picture,
	 *    even if the picture is animated. The plugin wraps those functions and says true.
	 * 2. Emoji, stickers and GIFs. `UserSettings.AnimateEmoji`, `AnimateStickers` and `GifAutoPlay` are the three
	 *    accessibility settings. The plugin makes them read "on".
	 * 3. Status emoji. `modules/activity_status/native/ActivityEmoji.tsx` animates only when its `emoji.animate` is true.
	 *    The plugin sets it.
	 * 4. Anything else with an `animate` or `canAnimate` property can be forced too (an option, off by default).
	 *
	 * The file reads top to bottom:  1 Settings  2 Counting  3 Pictures  4 Emoji, stickers, GIFs  5 Status emoji
	 *                                6 Everything else  7 Self-check  8 Settings screen  9 The plugin
	 * Keep `(function` as the first thing in this file: Valenced loads it as `return <file>`.
	 */

	const VERSION = '1.3.1'

	// ---------------------------------------------------------------------------------------------------
	// Small helpers
	// ---------------------------------------------------------------------------------------------------
	const toast = (text) => {
		try { valenced.discord.actions.ToastActionCreators.open('MARKLONG_ALWAYS_ANIMATE', { text: String(text) }) } catch (e) {}
	}
	/** Builds a React element with the JSX runtime, so the file needs no build step. */
	function h(type, props, ...children) {
		const runtime = valenced.react.ReactJSXRuntime
		const { key, ...rest } = props || {}
		if (children.length === 1) rest.children = children[0]
		else if (children.length > 1) rest.children = children
		return (children.length > 1 ? runtime.jsxs : runtime.jsx)(type, rest, key)
	}
	/** The name of a React component, from the element that was just made. */
	function componentName(element) {
		const type = element && element.type
		if (!type || typeof type === 'string') return ''
		const inner = type.type || type.render || type
		return type.displayName || type.name || (inner && (inner.displayName || inner.name)) || ''
	}
	const isPlainObject = (value) => !!value && typeof value === 'object' && !Array.isArray(value)

	// ---------------------------------------------------------------------------------------------------
	// 1. Settings
	// ---------------------------------------------------------------------------------------------------
	/** Every switch, in the order the settings screen shows them. `on` is the default. */
	const FEATURES = [
		{ key: 'pictures', on: true, title: 'Pictures', blurb: 'Profile pictures, server profile pictures, banners, avatar decorations and server icons.' },
		{ key: 'emoji', on: true, title: 'Emoji', blurb: 'Animated emoji everywhere, as if "Animate emoji" were on.' },
		{ key: 'stickers', on: true, title: 'Stickers', blurb: 'Animated stickers, as if "Animate stickers" were on.' },
		{ key: 'gifs', on: true, title: 'GIFs', blurb: 'GIFs play by themselves, as if "Play GIFs automatically" were on.' },
		{ key: 'statusEmoji', on: true, title: 'Status emoji', blurb: 'The emoji of a custom status.' },
		{ key: 'chat', on: true, title: 'Chat: pictures and decorations next to messages', blurb: 'The profile picture and avatar decoration beside each message. Discord builds these from plain addresses, so they are fixed on the way to the chat.' },
		{ key: 'addresses', on: true, title: 'Still pictures of animated things', blurb: 'A safety net: when a screen is about to show the still version of an animated server icon, profile picture or banner, it gets the animated one. This catches what the other switches miss, for example the server list.' },
		{ key: 'everything', on: false, title: 'Everything else (advanced)', blurb: 'Switches on every `animate` or `canAnimate` property Discord gives its screens. This can animate things Discord keeps still on purpose.' },
	]
	const defaults = { ...Object.fromEntries(FEATURES.map((f) => [f.key, f.on])), chatFormat: 'webp' }

	let storage
	let screenListeners = []
	const redrawSettings = () => screenListeners.slice().forEach((redraw) => { try { redraw() } catch (e) {} })

	function setting(key) {
		const saved = storage && storage.cache && storage.cache[key]
		return saved !== undefined ? saved : defaults[key]
	}
	function saveSettings(patch) {
		try { if (storage && typeof storage.set === 'function') storage.set(patch) } catch (e) {}
		try { if (storage && storage.cache) Object.assign(storage.cache, patch) } catch (e) {}
		redrawSettings()
	}

	// ---------------------------------------------------------------------------------------------------
	// 2. Counting, so the settings screen can say what really happened
	// ---------------------------------------------------------------------------------------------------
	const forced = Object.fromEntries(FEATURES.map((f) => [f.key, 0])) // how many times each feature changed something
	const seen = Object.fromEntries(FEATURES.map((f) => [f.key, 0])) // how many times Discord used the thing that was wrapped
	const perFunction = {} // pictures only: function name -> { seen, changed }
	let selfCheckRunning = false // the plugin's own test calls are not counted
	const found = {} // what was found in Discord: { pictures: 'AvatarUtils (2 holders, 19 functions)', ... }
	const problems = []
	function countSeen(feature, changed, detail) {
		if (selfCheckRunning) return
		seen[feature] += 1
		if (changed) forced[feature] += 1
		if (detail) {
			const entry = perFunction[detail] || (perFunction[detail] = { seen: 0, changed: 0 })
			entry.seen += 1
			if (changed) entry.changed += 1
		}
		if (seen[feature] <= 3 || seen[feature] % 50 === 0) redrawSettings()
	}
	function reportProblem(what, error) {
		const text = `${what}: ${String((error && error.message) || error).slice(0, 80)}`
		if (!problems.includes(text) && problems.length < 6) problems.push(text)
	}

	// ---------------------------------------------------------------------------------------------------
	// Finding Discord's code. `getModules` reports the modules that match now and the ones loaded later (many are
	// loaded only when a screen first needs them, which can be after this plugin started); a plain lookup covers
	// the ones that were loaded before. Everything that is hooked is hooked only once.
	// ---------------------------------------------------------------------------------------------------
	const watchers = []
	function watchModules(cleanup, makeFilter, attach) {
		const finders = valenced.modules.finders
		const run = (mod) => { try { attach(mod) } catch (e) { reportProblem('hook', e) } }
		let filter
		try { filter = makeFilter(finders.filters) } catch (e) { reportProblem('filter', e); return }
		try { if (typeof finders.getModules === 'function') cleanup(finders.getModules(filter, run)) } catch (e) { reportProblem('watch', e) }
		const again = () => { try { finders.lookupModule(filter).forEach(run) } catch (e) {} }
		again()
		watchers.push(again)
	}
	/** Looks again for everything that has not been found yet. Hooks that are already in place are skipped. */
	function lookAgain() { watchers.slice().forEach((again) => { try { again() } catch (e) {} }) }

	// ---------------------------------------------------------------------------------------------------
	// 3. Pictures: AvatarUtils
	// ---------------------------------------------------------------------------------------------------
	/**
	 * Where each AvatarUtils function takes its "may it animate" answer.
	 *   flag: a true/false at that argument position      options: an object with a `canAnimate` property at that position
	 */
	const PICTURE_FUNCTIONS = {
		// the user's picture: (user, canAnimate, size, png, webp) and its "source" form
		getUserAvatarURL: { flag: 1 },
		getUserAvatarSource: { flag: 1 },
		getGuildMemberAvatarURL: { flag: 1 },
		getGuildMemberAvatarSource: { flag: 2 },
		getAnimatableSourceWithFallback: { flag: 0 },
		// everything that takes an options object
		getGuildMemberAvatarURLSimple: { options: 0 },
		getUserBannerURL: { options: 0 },
		getGuildMemberBannerURL: { options: 0 },
		getAvatarDecorationURL: { options: 0 },
		getGuildIconURL: { options: 0 },
		getGuildIconSource: { options: 0 },
		getGuildBannerURL: { options: 0 },
		getGuildBannerSource: { options: 0 },
		getGuildSplashURL: { options: 0 },
		getGuildSplashSource: { options: 0 },
		getGuildHomeHeaderURL: { options: 0 },
		getGuildHomeHeaderSource: { options: 0 },
		getGuildDiscoverySplashURL: { options: 0 },
		getGuildDiscoverySplashSource: { options: 0 },
		getGuildTemplateIconURL: { options: 0 },
		getGuildTemplateIconSource: { options: 0 },
		getApplicationIconURL: { options: 0 },
		getApplicationIconSource: { options: 0 },
		getChannelIconURL: { options: 0 },
		getChannelIconSource: { options: 0 },
	}

	/** The arguments with "may animate" set to true. Returns the same array when nothing needs to change. */
	function withAnimationAllowed(args, where) {
		if (where.flag !== undefined) {
			if (args[where.flag] === true) return args
			const next = args.slice()
			next[where.flag] = true
			return next
		}
		const options = args[where.options]
		if (!isPlainObject(options) || options.canAnimate === true) return args
		const next = args.slice()
		next[where.options] = { ...options, canAnimate: true }
		return next
	}

	/** Wraps one function of a module so that `canAnimate` is true whenever the switch is on. */
	function allowAnimationIn(holder, name, where, cleanup) {
		const original = holder[name]
		if (typeof original !== 'function' || original.__alwaysAnimate) return false
		try {
			cleanup(valenced.patcher.instead(holder, name, function (args, callOriginal) {
				if (!setting('pictures')) return Reflect.apply(callOriginal, this, args)
				const next = withAnimationAllowed(args, where)
				countSeen('pictures', next !== args, name)
				return Reflect.apply(callOriginal, this, next)
			}))
			try { holder[name].__alwaysAnimate = true } catch (e) {}
			return true
		} catch (e) {
			reportProblem(`could not wrap ${name}`, e) // for example a function that cannot be replaced
			return false
		}
	}

	/** AvatarUtils can be reached as the module itself and as its `default` object. Both get the same treatment. */
	function holdersOf(modules) {
		const holders = []
		modules.forEach((mod) => {
			;[mod, mod && mod.default].forEach((holder) => { if (holder && typeof holder === 'object' && !holders.includes(holder)) holders.push(holder) })
		})
		return holders
	}
	const avatarHolders = [] // every AvatarUtils object that was found, for the self-check
	function allowPictureAnimations(cleanup) {
		watchModules(cleanup, (filters) => filters.withProps('getUserAvatarURL', 'getGuildIconURL'), (mod) => {
			holdersOf([mod]).forEach((holder) => {
				if (!avatarHolders.includes(holder)) avatarHolders.push(holder)
				Object.keys(PICTURE_FUNCTIONS).forEach((name) => allowAnimationIn(holder, name, PICTURE_FUNCTIONS[name], cleanup))
			})
			const wrapped = avatarHolders.reduce((total, holder) => total + Object.keys(PICTURE_FUNCTIONS).filter((name) => holder[name] && holder[name].__alwaysAnimate).length, 0)
			found.pictures = `AvatarUtils (${avatarHolders.length} place${avatarHolders.length === 1 ? '' : 's'}, ${wrapped} functions)`
		})
		if (!found.pictures) found.pictures = 'not found'
	}

	// ---------------------------------------------------------------------------------------------------
	// 4. Emoji, stickers and GIFs: three accessibility settings
	// ---------------------------------------------------------------------------------------------------
	/** `UserSettings.<name>` has `getSetting()` and `useSetting()`. Both are made to answer true while the switch is on. */
	const ACCESSIBILITY_SETTINGS = [
		{ name: 'AnimateEmoji', feature: 'emoji' },
		{ name: 'AnimateStickers', feature: 'stickers' },
		{ name: 'GifAutoPlay', feature: 'gifs' },
	]
	const accessibilityRoots = []
	const patchedSettings = new WeakSet()
	function allowAccessibilityAnimations(cleanup) {
		watchModules(cleanup, (filters) => filters.withProps('AnimateEmoji', 'AnimateStickers', 'GifAutoPlay'), (mod) => {
			const root = mod && (mod.AnimateEmoji ? mod : mod.default)
			if (!root) return
			if (!accessibilityRoots.includes(root)) accessibilityRoots.push(root)
			ACCESSIBILITY_SETTINGS.forEach(({ name, feature }) => {
				const target = root[name]
				if (!target) { found[feature] = found[feature] || 'not found'; return }
				if (patchedSettings.has(target)) return
				patchedSettings.add(target)
				const methods = ['getSetting', 'useSetting'].filter((method) => typeof target[method] === 'function')
				methods.forEach((method) => {
					cleanup(valenced.patcher.after(target, method, (result) => {
						if (!setting(feature)) return result
						countSeen(feature, result !== true)
						return true
					}))
				})
				found[feature] = `UserSettings.${name} (${methods.join(', ')})`
			})
		})
		ACCESSIBILITY_SETTINGS.forEach(({ feature }) => { if (!found[feature]) found[feature] = 'not found' })
	}

	// ---------------------------------------------------------------------------------------------------
	// 5. Status emoji and 6. everything else: elements as they are made
	// ---------------------------------------------------------------------------------------------------
	const ANIMATION_PROPS = ['animate', 'canAnimate', 'shouldAnimate']

	/** The status emoji only animates when its own `emoji.animate` is true. */
	function animateStatusEmoji(element) {
		const props = element.props
		if (componentName(element) !== 'ActivityEmoji' || !isPlainObject(props.emoji)) return element
		if (props.emoji.animate === true) { countSeen('statusEmoji', false); return element }
		countSeen('statusEmoji', true)
		return valenced.react.React.cloneElement(element, { emoji: { ...props.emoji, animate: true } })
	}
	/** Any screen that was told not to animate is told to. */
	function animateEverything(element) {
		const props = element.props
		if (!isPlainObject(props) || typeof element.type === 'string') return element
		const switchedOff = ANIMATION_PROPS.filter((name) => props[name] === false)
		if (!switchedOff.length) return element
		countSeen('everything', true)
		const patch = Object.fromEntries(switchedOff.map((name) => [name, true]))
		return valenced.react.React.cloneElement(element, patch)
	}

	// A picture's address says if it is the still or the animated one: an animated picture has a hash that starts with
	// "a_" and, when asked for as animated, ends in .gif or .webp?animated=true. Discord's server list (GuildsBarGuild)
	// asks for the animated one only for the open server.
	const STILL_ADDRESS = /(\/a_[0-9a-f]{6,})\.(png|jpe?g|webp)(\?[^#]*)?$/i
	function animatedAddress(uri) {
		if (typeof uri !== 'string' || uri.indexOf('/a_') < 0 || !/discord(app)?\.(com|net)|discordapp/.test(uri)) return uri
		const m = uri.match(STILL_ADDRESS)
		if (!m) return uri
		const query = m[3] || ''
		if (/[?&]animated=true/.test(query)) return uri
		const head = uri.slice(0, m.index) + m[1]
		return m[2].toLowerCase() === 'webp' ? `${head}.webp${query ? `${query}&animated=true` : '?animated=true'}` : `${head}.gif${query}`
	}
	// Decorations: a preset decoration is .../avatar-decoration-presets/<asset>.png?size=..&passthrough=false and
	// passthrough=true is the animated one. A shop decoration ends in /static or /animated.
	function animatedDecoration(uri) {
		if (typeof uri !== 'string') return uri
		if (uri.indexOf('avatar-decoration-presets') >= 0 && /[?&]passthrough=false/.test(uri)) return uri.replace(/([?&]passthrough=)false/, '$1true')
		return uri.replace(/(\/media\/v1\/collectibles-shop\/[^?#]*\/)static(?=[?#]|$)/, '$1animated')
	}
	/**
	 * Discord's chat is drawn natively from a row of plain data: `createMessageContent` returns it, with the address
	 * of the author's picture (`avatarURL`) and decoration (`avatarDecorationURL`) already worked out. This is the
	 * last place to make both animated.
	 */
	const chatSeen = new WeakSet()
	let chatSample = '' // the first address pair that was changed, for the report
	let chatAvatarSample = '' // the first animated profile picture address that went to the chat
	const chatCounts = { rows: 0, animatedAvatars: 0, decorations: 0 }
	function animateChatRow(row) {
		if (!row || typeof row !== 'object') return row
		let changed = false
		if (typeof row.avatarURL === 'string') {
			let next = animatedAddress(row.avatarURL)
			if (setting('chatFormat') === 'gif') next = asGif(next)
			if (next !== row.avatarURL) { row.avatarURL = next; changed = true }
		}
		if (typeof row.avatarDecorationURL === 'string') { const next = animatedDecoration(row.avatarDecorationURL); if (next !== row.avatarDecorationURL) { row.avatarDecorationURL = next; changed = true } }
		if (!chatSeen.has(row)) {
			const hasDecoration = typeof row.avatarDecorationURL === 'string' && row.avatarDecorationURL
			const animatedAvatar = typeof row.avatarURL === 'string' && /\/a_[0-9a-f]{6,}\./i.test(row.avatarURL)
			chatCounts.rows += 1
			if (animatedAvatar) { chatCounts.animatedAvatars += 1; if (!chatAvatarSample) chatAvatarSample = String(row.avatarURL).replace(/^https?:\/\//, '').slice(0, 90) }
			if (hasDecoration) chatCounts.decorations += 1
		}
		if (changed && !chatSample) chatSample = `${String(row.avatarURL || '').replace(/^https?:\/\//, '').slice(0, 80)} | ${String(row.avatarDecorationURL || '').replace(/^https?:\/\//, '').slice(-60)}`
		if (changed || !chatSeen.has(row)) { chatSeen.add(row); countSeen('chat', changed) }
		return row
	}
	function hookChatRows(cleanup) {
		// 1. `generateMessageRowData(...)` (MessageWithContent.tsx) returns { type, message: <the row data>, ... }. It is a
		//    named export, so it can be found by name, and the row data is in `.message`.
		const patchedRows = new WeakSet()
		watchModules(cleanup, (filters) => filters.withProps('generateMessageRowData'), (mod) => {
			;[mod, mod && mod.default].forEach((holder) => {
				if (!holder || (typeof holder !== 'object' && typeof holder !== 'function') || typeof holder.generateMessageRowData !== 'function' || patchedRows.has(holder)) return
				patchedRows.add(holder)
				cleanup(valenced.patcher.after(holder, 'generateMessageRowData', (result) => {
					if (!setting('chat')) return result
					try { if (result && typeof result === 'object') animateChatRow(result.message) } catch (e) { reportProblem('chat row', e) }
					return result
				}))
				found.chat = 'generateMessageRowData (the chat rows)'
			})
		})
		// 2. `createMessageContent` itself, a default export found by its name (the same row data, also used by reply previews).
		const patched = new WeakSet()
		watchModules(cleanup, (filters) => filters.withName('createMessageContent'), (mod) => {
			;[mod, mod && mod.default].forEach((holder) => {
				if (!holder || (typeof holder !== 'object' && typeof holder !== 'function')) return
				if (typeof holder.default !== 'function' || patched.has(holder) || (holder.default.name && holder.default.name !== 'createMessageContent')) return
				patched.add(holder)
				cleanup(valenced.patcher.after(holder, 'default', (result) => { if (!setting('chat')) return result; try { return animateChatRow(result) } catch (e) { reportProblem('chat row', e); return result } }))
				if (!found.chat || found.chat === 'not found') found.chat = 'createMessageContent (the chat rows)'
			})
		})
		if (!found.chat) found.chat = 'not found'
	}

	/** The same animated picture as a .gif address: the chat may play that kind where it ignores animated webp. */
	function asGif(uri) {
		if (typeof uri !== 'string' || uri.indexOf('/a_') < 0) return uri
		const m = uri.match(/(\/a_[0-9a-f]{6,})\.(png|jpe?g|webp)(\?[^#]*)?$/i)
		if (!m) return uri
		const query = (m[3] || '').replace(/([?&])animated=true&?/, '$1').replace(/[?&]$/, '')
		return `${uri.slice(0, m.index)}${m[1]}.gif${query}`
	}

	/** Rewrites the `source` of an image element when it points at the still version of an animated picture. */
	function animateAddresses(element) {
		const props = element.props
		const source = props && props.source
		if (!source || typeof source !== 'object') return element
		let changed = false
		const fix = (one) => {
			if (!one || typeof one !== 'object' || typeof one.uri !== 'string') return one
			const next = animatedAddress(one.uri)
			if (next === one.uri) return one
			changed = true
			return { ...one, uri: next }
		}
		const fixed = Array.isArray(source) ? source.map(fix) : fix(source)
		if (!changed) return element
		countSeen('addresses', true)
		return valenced.react.React.cloneElement(element, { source: fixed })
	}

	/** Makes the pictures that are already on screen be drawn again, now that the plugin is in place. */
	function refreshPictures() {
		let count = 0
		try {
			const stores = valenced.discord.flux.Stores
			;['GuildStore', 'GuildMemberStore', 'UserStore', 'MessageStore'].forEach((name) => {
				const store = stores && stores[name]
				if (store && typeof store.emitChange === 'function') { store.emitChange(); count += 1 }
			})
		} catch (e) { reportProblem('refresh', e) }
		refreshed.count += count ? 1 : 0
		refreshed.at = Date.now()
		return count
	}
	const refreshed = { count: 0, at: 0 }
	const PICTURE_SWITCHES = ['pictures', 'addresses', 'chat', 'everything']
	let refreshTimer
	/** After a switch changed, the pictures on screen are drawn again once things have settled. */
	function scheduleRefresh() {
		clearTimeout(refreshTimer)
		refreshTimer = setTimeout(refreshPictures, 300)
	}

	function animateElements(cleanup) {
		const finders = valenced.modules.finders
		const runtime = finders.lookupModule(finders.filters.withProps('jsx', 'jsxs'))[0] || valenced.react.ReactJSXRuntime
		const onNewElement = (element) => {
			if (!element || !element.props) return element
			let result = element
			if (setting('addresses')) result = animateAddresses(result)
			if (setting('statusEmoji')) result = animateStatusEmoji(result)
			if (setting('everything')) result = animateEverything(result)
			return result
		}
		let hooked = 0
		;['jsx', 'jsxs'].forEach((name) => {
			if (runtime && typeof runtime[name] === 'function') { cleanup(valenced.patcher.after(runtime, name, onNewElement)); hooked += 1 }
		})
		found.addresses = hooked ? 'every picture address' : 'not found'
		found.statusEmoji = hooked ? 'every new screen element (ActivityEmoji)' : 'not found'
		found.everything = hooked ? 'every new screen element' : 'not found'
	}

	// ---------------------------------------------------------------------------------------------------
	// 7. Self-check: asks Discord for a made-up animated picture and looks at the address it gives back
	// ---------------------------------------------------------------------------------------------------
	const FAKE_USER = { id: '123456789012345678', avatar: 'a_0123456789abcdef0123456789abcdef', discriminator: '0', username: 'check' }
	const FAKE_ICON = { id: '123456789012345678', icon: 'a_0123456789abcdef0123456789abcdef', size: 64, canAnimate: false }

	function addressOf(value) {
		if (typeof value === 'string') return value
		if (value && typeof value.uri === 'string') return value.uri
		if (Array.isArray(value)) return addressOf(value[0])
		return ''
	}
	/** @returns {{ label: string, ok: boolean, detail: string }[]} */
	function runSelfCheck() {
		selfCheckRunning = true
		try { return runSelfCheckNow() } finally { selfCheckRunning = false }
	}
	function runSelfCheckNow() {
		const results = []
		const finders = valenced.modules.finders
		lookAgain()
		const utils = avatarHolders[0]
		const check = (label, make) => {
			if (!utils) { results.push({ label, ok: false, detail: 'AvatarUtils was not found' }); return }
			try {
				const address = addressOf(make(utils))
				const animated = /\.gif(\?|$)|animated=true/.test(address)
				results.push({ label, ok: animated, detail: address ? address.replace(/^https?:\/\//, '').slice(0, 70) : 'no address came back' })
			} catch (e) { results.push({ label, ok: false, detail: `error: ${String((e && e.message) || e).slice(0, 60)}` }) }
		}
		check('A profile picture, asked for as "still"', (u) => u.getUserAvatarURL(FAKE_USER, false, 64))
		check('A server icon, asked for as "still"', (u) => u.getGuildIconURL({ ...FAKE_ICON }))
		results.push(...settingChecks())
		return results
	}
	function settingChecks() {
		const finders = valenced.modules.finders
		const root = accessibilityRoots[0]
		return ACCESSIBILITY_SETTINGS.map(({ name, feature }) => {
			const label = `Setting "${name}" reads`
			if (!root || !root[name] || typeof root[name].getSetting !== 'function') return { label, ok: false, detail: 'not found' }
			try {
				const value = root[name].getSetting()
				return { label, ok: value === true || !setting(feature), detail: String(value) + (setting(feature) ? '' : ' (this switch is off)') }
			} catch (e) { return { label, ok: false, detail: `error: ${String((e && e.message) || e).slice(0, 60)}` } }
		})
	}

	function buildReport() {
		const lines = ['Always Animate report', `version: ${VERSION}`]
		lines.push(`chat picture format: ${setting('chatFormat')}; chat sample: ${chatSample || 'none yet'}`)
		lines.push(`chat rows seen ${chatCounts.rows}: with an animated profile picture ${chatCounts.animatedAvatars}, with a decoration ${chatCounts.decorations}; animated picture sample: ${chatAvatarSample || 'none yet'}`)
		lines.push(`pictures drawn again: ${refreshed.count}x${refreshed.at ? `, last ${new Date(refreshed.at).toLocaleTimeString()}` : ''}`)
		FEATURES.forEach((f) => lines.push(`${f.key}: ${setting(f.key) ? 'on' : 'off'}; ${found[f.key] || 'not hooked'}; Discord used it ${seen[f.key]} time(s), changed ${forced[f.key]}`))
		const top = Object.keys(perFunction).sort((a, b) => perFunction[b].seen - perFunction[a].seen).slice(0, 8)
		if (top.length) lines.push(`pictures by function (used/changed): ${top.map((n) => `${n} ${perFunction[n].seen}/${perFunction[n].changed}`).join(', ')}`)
		runSelfCheck().forEach((r) => lines.push(`check - ${r.label}: ${r.ok ? 'ok' : 'FAIL'} ${r.detail}`))
		if (problems.length) lines.push(`problems: ${problems.join(' | ')}`)
		return lines.join('\n')
	}
	function copyReport() {
		try {
			valenced.externals.ReactNativeClipboard.Clipboard.setString(buildReport())
			toast('Report copied. Paste it in the chat.')
		} catch (e) { toast('Could not copy') }
	}

	// ---------------------------------------------------------------------------------------------------
	// 8. Settings screen
	// ---------------------------------------------------------------------------------------------------
	function Card({ children }) {
		const { View } = valenced.react.ReactNative
		return h(View, { style: { borderRadius: 14, padding: 14, gap: 10, backgroundColor: '#2b2d31' } }, children)
	}
	function Pill({ text, color }) {
		const { View } = valenced.react.ReactNative
		const { Text } = valenced.discord.design.Design
		return h(View, { style: { paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999, backgroundColor: `${color}33` } }, h(Text, { variant: 'text-xs/bold', style: { color } }, text))
	}
	function Radio({ title, value, items, onChange }) {
		const Design = valenced.discord.design.Design
		return h(Design.TableRadioGroup, { title, value, onChange }, items.map((item) => h(Design.TableRadioRow, { key: String(item.v), label: item.l, subLabel: item.s, value: item.v })))
	}
	const GREEN = '#23a55a'
	const RED = '#f23f43'
	const AMBER = '#f0b232'
	const GRAY = '#80848e'

	/** How a feature is doing: Off, Not found, Ready (hooked, not used yet), Used (nothing needed changing) or Working. */
	function featureState(feature) {
		if (!setting(feature)) return { text: 'Off', color: GRAY }
		if (!found[feature] || found[feature] === 'not found') return { text: 'Not found', color: RED }
		if (forced[feature] > 0) return { text: `Working · ${forced[feature]} of ${seen[feature]}`, color: GREEN }
		return seen[feature] > 0 ? { text: `Used ${seen[feature]} times, already animated`, color: GREEN } : { text: 'Ready, waiting for Discord to use it', color: AMBER }
	}

	function SettingsScreen({ api }) {
		const { React, ReactNative: RN } = valenced.react
		const Design = valenced.discord.design.Design
		storage = api.jsonStorage
		storage.use()

		const [, setRedraws] = React.useState(0)
		const [checks, setChecks] = React.useState(null)
		React.useEffect(() => {
			const redraw = () => setRedraws((n) => n + 1)
			screenListeners.push(redraw)
			return () => { screenListeners = screenListeners.filter((l) => l !== redraw) }
		}, [])

		const featureRow = (feature) => {
			const state = featureState(feature.key)
			return h(
				RN.View,
				{ key: feature.key, style: { gap: 6 } },
				h(Design.TableSwitchRow, { label: feature.title, subLabel: feature.blurb, value: !!setting(feature.key), onValueChange: (value) => { saveSettings({ [feature.key]: !!value }); if (PICTURE_SWITCHES.includes(feature.key)) scheduleRefresh() } }),
				h(RN.View, { style: { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingBottom: 6 } },
					h(Pill, { text: state.text, color: state.color }),
					found[feature.key] && h(Design.Text, { variant: 'text-xs/medium', color: 'text-muted', numberOfLines: 1, style: { flex: 1 } }, found[feature.key])),
			)
		}
		const onCount = FEATURES.filter((f) => setting(f.key)).length
		const working = FEATURES.filter((f) => setting(f.key) && forced[f.key] > 0).length

		return h(
			RN.ScrollView,
			{ style: { flex: 1 }, contentContainerStyle: { paddingBottom: 38 }, keyboardShouldPersistTaps: 'handled' },
			h(
				Design.Stack,
				{ style: { paddingVertical: 20, paddingHorizontal: 12 }, spacing: 22 },
				h(
					Card,
					null,
					h(Design.Text, { variant: 'heading-lg/bold' }, `Always Animate ${VERSION}`),
					h(Design.Text, { variant: 'text-sm/medium', color: 'text-muted' }, `${onCount} of ${FEATURES.length} switches are on, ${working} already changed something. Pictures that were already on screen are drawn again after a switch changes or when you tap "Refresh the pictures on screen".`),
					h(RN.View, { style: { flexDirection: 'row', gap: 10 } },
						h(RN.View, { style: { flex: 1 } }, h(Design.Button, { text: 'Run the self-check', variant: 'primary', size: 'sm', onPress: () => setChecks(runSelfCheck()) })),
						h(RN.View, { style: { flex: 1 } }, h(Design.Button, { text: 'Copy report', variant: 'secondary', size: 'sm', onPress: copyReport }))),
					h(Design.Button, { text: 'Refresh the pictures on screen', variant: 'secondary', size: 'sm', onPress: () => { const n = refreshPictures(); toast(n ? 'Pictures are drawn again. Server icons and pictures should animate now.' : 'Could not refresh. Switch server or restart Discord.') } }),
				),
				checks && h(
					Design.TableRowGroup,
					{ title: 'Self-check' },
					...checks.map((r, i) => h(Design.TableRow, { key: `check${i}`, label: `${r.ok ? '✓' : '✗'} ${r.label}`, subLabel: r.detail })),
					h(Design.TableRow, { key: 'checkNote', label: 'What this shows', subLabel: 'The plugin asks Discord for a made-up animated picture as "still". A ✓ means the address came back animated (.gif), so the plugin works.' }),
				),
				h(RN.View, { style: { gap: 4 } },
					h(Design.Text, { variant: 'text-sm/semibold', color: 'text-muted' }, 'WHAT ANIMATES'),
					h(Design.TableRowGroup, { title: '' }, ...FEATURES.slice(0, 7).map(featureRow))),
				setting('chat') && h(Radio, { key: 'chatFormat', title: 'Chat: kind of animated picture', value: setting('chatFormat'), onChange: (v) => { saveSettings({ chatFormat: v }); scheduleRefresh() }, items: [
					{ v: 'webp', l: 'Animated webp', s: 'What Discord uses for animated pictures' },
					{ v: 'gif', l: 'GIF', s: 'Try this if the chat does not play the webp. Only for profile pictures' },
				] }),
				h(Design.TableRowGroup, { title: 'Advanced' }, featureRow(FEATURES[7])),
				h(
					Design.TableRowGroup,
					{ title: 'Good to know' },
					h(Design.TableRow, { key: 'k1', label: 'Battery and data', subLabel: 'Animated pictures use more battery and more data than still ones. Turn off what you do not need.' }),
					h(Design.TableRow, { key: 'k2', label: 'Reduce Motion', subLabel: 'Your phone\'s Reduce Motion setting is not changed by this plugin.' }),
					problems.length > 0 && h(Design.TableRow, { key: 'problems', label: 'Problems', subLabel: problems.join(' · ') }),
				),
			),
		)
	}

	// ---------------------------------------------------------------------------------------------------
	// 9. The plugin
	// ---------------------------------------------------------------------------------------------------
	Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
	exports.default = plugin({
		jsonStorage: { load: true, default: defaults },
		SettingsComponent: SettingsScreen,
		start(api) {
			storage = api.jsonStorage
			const attempt = (what, step) => { try { step() } catch (e) { reportProblem(what, e) } }
			attempt('pictures', () => allowPictureAnimations(api.cleanup))
			attempt('emoji, stickers and GIFs', () => allowAccessibilityAnimations(api.cleanup))
			attempt('status emoji', () => animateElements(api.cleanup))
			attempt('chat rows', () => hookChatRows(api.cleanup))
			// The server list and other screens were drawn before the plugin was in place: draw them again.
			const timers = [1500, 5000].map((ms) => setTimeout(refreshPictures, ms))
			// What was not found yet is looked for again a few times, and the pictures drawn again when it turns up.
			const looks = [1500, 4000, 10000, 25000].map((ms) => setTimeout(() => { const before = JSON.stringify(found); lookAgain(); if (JSON.stringify(found) !== before) scheduleRefresh() }, ms))
			api.cleanup(() => { screenListeners = []; timers.concat(looks).forEach(clearTimeout); clearTimeout(refreshTimer); watchers.length = 0 })
		},
	})
	return exports
})({})
